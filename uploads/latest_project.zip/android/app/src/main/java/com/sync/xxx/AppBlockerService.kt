package com.sync.xxx

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class AppBlockerService : AccessibilityService() {

    companion object {
        var instance: AppBlockerService? = null
        val blockedPackages = mutableSetOf<String>()

        fun isEnabled(ctx: Context): Boolean {
            val enabledServices = android.provider.Settings.Secure.getString(
                ctx.contentResolver,
                android.provider.Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val component = "${ctx.packageName}/.AppBlockerService"
            val componentFull = "${ctx.packageName}/${ctx.packageName}.AppBlockerService"
            return enabledServices.split(":").any { svc ->
                svc.equals(component, ignoreCase = true) ||
                svc.equals(componentFull, ignoreCase = true)
            }
        }

        fun isUsageAccessGranted(ctx: Context): Boolean {
            return try {
                val appOps = ctx.getSystemService(Context.APP_OPS_SERVICE) as android.app.AppOpsManager
                val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    appOps.unsafeCheckOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                } else {
                    @Suppress("DEPRECATION")
                    appOps.checkOpNoThrow(
                        android.app.AppOpsManager.OPSTR_GET_USAGE_STATS,
                        android.os.Process.myUid(), ctx.packageName
                    )
                }
                mode == android.app.AppOpsManager.MODE_ALLOWED
            } catch (e: Exception) { false }
        }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var lastBlockedPkg = ""
    private var lastBlockTime = 0L
    private var overlayView: View? = null
    private var windowManager: WindowManager? = null

    private val commandReceiver = object : BroadcastReceiver() {
        override fun onReceive(ctx: Context, intent: Intent) {
            when (intent.action) {
                "com.sync.xxx.BLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.add(pkg)
                    android.util.Log.d("AppBlocker", "Blocked: $pkg")
                }
                "com.sync.xxx.UNBLOCK_APP" -> {
                    val pkg = intent.getStringExtra("package") ?: return
                    blockedPackages.remove(pkg)
                    android.util.Log.d("AppBlocker", "Unblocked: $pkg")
                }
                "com.sync.xxx.UNBLOCK_ALL" -> {
                    blockedPackages.clear()
                    android.util.Log.d("AppBlocker", "All unblocked")
                }
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        serviceInfo = serviceInfo.apply {
            eventTypes = AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED
            feedbackType = AccessibilityServiceInfo.FEEDBACK_GENERIC
            flags = AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS
            notificationTimeout = 0
        }

        val filter = IntentFilter().apply {
            addAction("com.sync.xxx.BLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_APP")
            addAction("com.sync.xxx.UNBLOCK_ALL")
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(commandReceiver, filter, RECEIVER_NOT_EXPORTED)
        } else {
            registerReceiver(commandReceiver, filter)
        }
        android.util.Log.d("AppBlocker", "Service connected")
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return
        if (pkg == "android") return
        if (pkg == "com.android.systemui") return

        if (!blockedPackages.contains(pkg)) {
            hideOverlay()
            return
        }

        // Anti spam
        val now = System.currentTimeMillis()
        if (pkg == lastBlockedPkg && now - lastBlockTime < 1000) return
        lastBlockedPkg = pkg
        lastBlockTime = now

        val appName = try {
            val pm = packageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                val appInfo = pm.getApplicationInfo(pkg, PackageManager.ApplicationInfoFlags.of(0))
                pm.getApplicationLabel(appInfo).toString()
            } else {
                @Suppress("DEPRECATION")
                val appInfo = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(appInfo).toString()
            }
        } catch (e: Exception) { 
            pkg 
        }

        // 1. LANGSUNG TAMPILKAN POPUP
        showBlockPopup(appName)

        // 2. LANGSUNG HOME (0 delay)
        performGlobalAction(GLOBAL_ACTION_HOME)
        
        // 3. Backup HOME
        mainHandler.postDelayed({
            performGlobalAction(GLOBAL_ACTION_HOME)
        }, 50)
    }

    private fun showBlockPopup(appName: String) {
        mainHandler.post {
            try {
                hideOverlay()

                // Container utama
                val container = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(Color.parseColor("#CC000000"))
                    gravity = Gravity.CENTER
                    setPadding(40, 40, 40, 40)
                }

                // Card putih
                val card = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setBackgroundColor(Color.WHITE)
                    setPadding(35, 35, 35, 35)
                    gravity = Gravity.CENTER
                    
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                        elevation = 30f
                    }
                }

                // Header dengan tombol X
                val headerLayout = LinearLayout(this).apply {
                    orientation = LinearLayout.HORIZONTAL
                    gravity = Gravity.END
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                }

                val closeButton = Button(this).apply {
                    text = "✕"
                    textSize = 30f
                    setTextColor(Color.parseColor("#999999"))
                    setBackgroundColor(Color.TRANSPARENT)
                    setPadding(15, 0, 15, 0)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.WRAP_CONTENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setOnClickListener {
                        hideOverlay()
                    }
                }
                headerLayout.addView(closeButton)
                card.addView(headerLayout)

                // Icon
                val icon = TextView(this).apply {
                    text = "🚫"
                    textSize = 80f
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, 10)
                }
                card.addView(icon)

                // Title
                val title = TextView(this).apply {
                    text = "AKSES DITOLAK!"
                    textSize = 26f
                    setTextColor(Color.parseColor("#E74C3C"))
                    gravity = Gravity.CENTER
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setPadding(0, 0, 0, 10)
                }
                card.addView(title)

                // Nama Aplikasi
                val appNameView = TextView(this).apply {
                    text = appName
                    textSize = 24f
                    setTextColor(Color.parseColor("#2C3E50"))
                    gravity = Gravity.CENTER
                    setTypeface(typeface, android.graphics.Typeface.BOLD)
                    setBackgroundColor(Color.parseColor("#F0F0F0"))
                    setPadding(25, 15, 25, 15)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    ).apply {
                        setMargins(0, 10, 0, 15)
                    }
                }
                card.addView(appNameView)

                // Divider
                val divider = View(this).apply {
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        3
                    ).apply {
                        setMargins(0, 10, 0, 15)
                    }
                    setBackgroundColor(Color.parseColor("#E74C3C"))
                }
                card.addView(divider)

                // Message
                val message = TextView(this).apply {
                    text = "Aplikasi ini telah diblokir\noleh Administrator"
                    textSize = 16f
                    setTextColor(Color.parseColor("#666666"))
                    gravity = Gravity.CENTER
                    setPadding(0, 0, 0, 25)
                }
                card.addView(message)

                // Button OK
                val okButton = Button(this).apply {
                    text = "OK, Saya Mengerti"
                    textSize = 16f
                    setTextColor(Color.WHITE)
                    setBackgroundColor(Color.parseColor("#E74C3C"))
                    setPadding(20, 18, 20, 18)
                    layoutParams = LinearLayout.LayoutParams(
                        LinearLayout.LayoutParams.MATCH_PARENT,
                        LinearLayout.LayoutParams.WRAP_CONTENT
                    )
                    setOnClickListener {
                        hideOverlay()
                    }
                }
                card.addView(okButton)

                container.addView(card)

                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    else
                        WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                    PixelFormat.TRANSLUCENT
                )

                windowManager?.addView(container, params)
                overlayView = container
                android.util.Log.d("AppBlocker", "Popup shown for: $appName")
            } catch (e: Exception) {
                android.util.Log.e("AppBlocker", "Error: ${e.message}")
                e.printStackTrace()
            }
        }
    }

    private fun hideOverlay() {
        mainHandler.post {
            try {
                overlayView?.let {
                    windowManager?.removeView(it)
                    overlayView = null
                    android.util.Log.d("AppBlocker", "Popup hidden")
                }
            } catch (e: Exception) {
                overlayView = null
            }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        super.onDestroy()
        try { unregisterReceiver(commandReceiver) } catch (_: Exception) {}
        hideOverlay()
        instance = null
    }
}